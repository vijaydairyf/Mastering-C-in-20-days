﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;



namespace AgrofarmWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ReturnsController : Controller
    {


        private readonly AgroFarmRepository _repository;
        private readonly IMapper _mapper;
        public ReturnsController(AgroFarmRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }


        //To fetch type of returns opted by investor
        [HttpGet]
        public JsonResult GetReturns()
        {
            List<TypeofReturn> returnList = _repository.GetReturn();
            return new JsonResult(returnList);
        }

    }
}


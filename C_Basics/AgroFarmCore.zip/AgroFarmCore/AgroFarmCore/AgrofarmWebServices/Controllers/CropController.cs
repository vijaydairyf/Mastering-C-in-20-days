﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;




namespace AgrofarmWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CropController : Controller
    {


        private readonly AgroFarmRepository _repository;
        private readonly IMapper _mapper;
        public CropController(AgroFarmRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        //[HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
        // To fetch all type of crops added by admin
        [HttpGet]
        public JsonResult GetCrops()
        {
            List<TypeofCrops> cropList = _repository.Getcrops();
            return new JsonResult(cropList);
        }

    }
}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AgrofarmWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class FarmerController : ControllerBase
    {
        private readonly AgroFarmRepository _repository;
        private readonly IMapper _mapper;
        public FarmerController(AgroFarmRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        // GET: api/Investors
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Investors/5
        //[HttpGet]
        //Fetch all Farmer details from farmer table
        [HttpGet]
        public JsonResult GetFarmers(string username)
        {


            Models.Farmer farmer = null;
            try
            {
                farmer = _mapper.Map<Models.Farmer>(_repository.GetAllDetails(username));
            }


            catch (Exception ex)
            {
                farmer = null;
            }
            return new JsonResult(farmer);
        }
        //Fetch all farmer personal details
        public JsonResult GetFarmerDetails(string username)
        {


            Models.Users user = null;
            try
            {
                user = _mapper.Map<Models.Users>(_repository.GetFarmerDetails(username));
            }


            catch (Exception ex)
            {
                user = null;
            }
            return new JsonResult(user);
        }
        //Add new farmer details in farmer table
        [HttpGet]
        public JsonResult AddFarmer(Models.Farmer farmer)
        {
            bool status = false;
            try
            {
                Farmers farmers = _mapper.Map<Farmers>(farmer);
                status = _repository.Add_Farmer(farmers.UserName, farmers.CropName, farmers.Land);
            }
            catch (Exception ex)
            {
                status = false;
            }
            return new JsonResult(status);
        }
        //Update farmer personal details
        //[HttpPut()]
        //public JsonResult UpdateFarmer(Models.Users user)
        //{
        //    bool status = false;

        //    try
        //    {
        //        Users user1 = _mapper.Map<Users>(user);
        //        status = _repository.UpdateFarmerUser(user1.Name, user1.Address, user1.PhoneNumber);
        //    }
        //    catch (Exception ex)
        //    {
        //        status = false;
        //    }
        //    return new JsonResult(status);
        //}


        //To fetch list of all farmers from users table
        [HttpGet]
        public JsonResult GetAllFarmers()
        {
            List<Users> userList = _repository.GetFarmers();
            return new JsonResult(userList);
        }

    }
}

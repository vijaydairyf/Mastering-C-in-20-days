﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AgrofarmWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class InvestorsController : ControllerBase
    {
        private readonly AgroFarmRepository _repository;
        private readonly IMapper _mapper;
        public InvestorsController(AgroFarmRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        // GET: api/Investors
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Investors/5
        //[HttpGet]
        //public JsonResult GetInvestors()
        //{
        //    List<Models.Investors> products = new List<Models.Investors>();
        //    try
        //    {
        //        string username=HttpContext.Session.GetString("username");
        //        List<Investors> productList = _repository.GetAll(username);
        //        if (productList != null)
        //        {
        //            foreach (var product in productList)
        //            {
        //                Models.Investors productObj = _mapper.Map<Models.Investors>(product);
        //                products.Add(productObj);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        products = null;
        //    }
        //    return new JsonResult(products);
        //}

        // POST: api/Investors
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Investors/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;

namespace AgrofarmWebServices
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<Investors, Models.Investors>();
            CreateMap<Users, Models.Users>();
            CreateMap<Models.Users, Users>();
            CreateMap<Models.Farmer, Farmers>();
            CreateMap<Farmers, Models.Farmer>();
            CreateMap<TypeofCrops, Models.TypeOfCrops>();
            CreateMap<TypeofReturn, Models.TypeOfReturns>();
        }
    }
}

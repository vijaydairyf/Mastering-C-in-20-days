﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgrofarmWebServices.Models
{
    public class Farmer
    {
        public string FarmerId { get; set; }
        public string UserName { get; set; }
        public string CropId { get; set; }
        public decimal Land { get; set; }
        public decimal TotalProductionCost { get; set; }
    }
}

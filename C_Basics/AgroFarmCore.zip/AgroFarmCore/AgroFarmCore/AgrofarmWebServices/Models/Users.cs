﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgrofarmWebServices.Models
{
    public class Users
    {

        public string UserName { get; set; }
        public string Name { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public decimal PhoneNumber { get; set; }
    }
}

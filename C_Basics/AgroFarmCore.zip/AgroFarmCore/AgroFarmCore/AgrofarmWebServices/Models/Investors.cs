﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgrofarmWebServices.Models
{
    public class Investors
    {
        public string InvestorId { get; set; }
        public string UserName { get; set; }
        public string CropId { get; set; }
        public decimal InvestmentAmount { get; set; }
        public string ReturnType { get; set; }
        public decimal Returns { get; set; }
    }
}

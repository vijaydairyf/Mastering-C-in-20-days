﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgrofarmWebServices.Models
{
    public class TypeOfReturns
    {
        public string CropId { get; set; }
        public decimal FixedReturn { get; set; }
        public decimal ProfitSharing { get; set; }
        public decimal ProductMaterial { get; set; }
    }
}

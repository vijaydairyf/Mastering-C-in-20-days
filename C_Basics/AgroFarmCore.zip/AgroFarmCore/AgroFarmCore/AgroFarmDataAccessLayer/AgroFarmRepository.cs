﻿using AgroFarmDataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace AgroFarmDataAccessLayer
{
    public class AgroFarmRepository
    {
        public int Test { get; set; }
        AgroFarmDBContext context;
        public AgroFarmRepository(AgroFarmDBContext _context)
        {
            context = _context;
        }

        public AgroFarmRepository()
        {
            context = new AgroFarmDBContext();
        }
        //Add entries in the investor table
        public bool Add_Investor(string username,string cropName, Decimal investmentAmount, string returnType)
        {
            bool status = false;
            

            try
            {
                var addInvestor = @"exec usp_AddInvestors @username,@cropname,@investmentamount,@returntype";

                context.Database.ExecuteSqlCommand(addInvestor, new SqlParameter("@username", username), new SqlParameter("@cropname", cropName), new SqlParameter("@investmentamount", investmentAmount),
                                                    new SqlParameter("@returntype", returnType));
                if (status == false)
                {
                    Test = -99;
                }
                else
                    Test = 1;

                status = true;
            }
            catch (Exception ex)
            {
                Test = -99;
                status = false;
            }
            return status;
        }
        //Add entries in the farmer table
        public bool Add_Farmer(string username, string cropName, Decimal land)
        {
            bool status = false;
            try
            {
                var addFarmer = @"exec usp_AddFarmers @username,@cropname,@land";

                context.Database.ExecuteSqlCommand(addFarmer, new SqlParameter("@username", username), new SqlParameter("@cropname", cropName), new SqlParameter("@land", land)
                                               );
                if (status == false)
                {
                    Test = -99;
                }
                else
                    Test = 1;

                status = true;
            }
            catch (Exception)
            {
                Test = -99;
                status = false;
            }
            return status;
        }
        //Add entries of user registration in the user table
        public bool Add_User(string username, string name, string password,string image,string role, string gender, string address, decimal number)
        {
            bool status = false;
            string img = "~/RegistrationImage/"+image;
            try
            {

                var addUser = @"exec usp_RegisterUser @username,@name,@password,@image,@role,@gender,@address,@number";

            context.Database.ExecuteSqlCommand(addUser, new SqlParameter("@username", username), new SqlParameter("@name", name), new SqlParameter("@password", password),
               new SqlParameter("@image",img), new SqlParameter("@role", role), new SqlParameter("@gender", gender), new SqlParameter("@address", address), new SqlParameter("@number", number)
                                           );
                if (status == false)
                {
                    Test = -99;
                }
                else
                    Test = 1;
                status = true;
                return status;
            }
            catch
            {
                Test = -99;
                status = false;
            }
            return status;

        }
        //To fetch all farmer table details
        public List<Farmers> GetAllDetails(string username)
        {
            try
            { 
            var detaillist = (from c in context.Farmers
                              where c.UserName == username
                              select c).ToList();
            if (detaillist.Count == 0)
            {
                Test = -99;
            }
            else
                Test = 1;
            return detaillist;
             }
            catch
            {
                Test = -99;
                return null;
            }
            
        }
        //To fetch farmer details from user table
        public Users GetFarmerDetails(string username)
        {
            Users user = null;
            try
            {
                user = context.Users.Where(p => p.UserName == username).FirstOrDefault();
                if (user == null)
                {
                    Test = -99;
                }
                else
                    Test = 1;
            }
            catch (Exception)
            {
                Test = -99;
                user = null;
            }

            return user;
        }
        //To Update farmer personal details in user table
        public bool UpdateFarmerUser(Users user)
        {
            bool status = false;
            Users user1 = context.Users.Find(user.UserName);
            try
            {
                if (user1 != null)
                {
                   
                    user1.Name = user.Name;
                    user1.Address = user.Address;
                    user1.PhoneNumber = user.PhoneNumber;
                    context.SaveChanges();
                    status = true;
                    Test = 1;
                }
                else
                {

                    status = false;
                    Test = -99;
                }
            }
            catch (Exception)
            {
                status = false;
                Test = -99;
            }
            return status;
        }
        //To fetch Investor entries from investor table
        public List<Investors> GetAllInvestors(string username)
        {
            try
            {
                var list = (from c in context.Investors
                            where c.UserName == username
                            select c).ToList();
                if (list.Count == 0)
                {
                    Test = -99;
                }
                else
                    Test = 1;
                return list;
            }
            catch
            {
                Test = -99;
                return null;
            }
        }
        //To fetch investor personal details from user table
        public Users GetInvestorDetails(string username)
        {
            Users user = null;
            try
            {
                user = context.Users.Where(p => p.UserName == username).FirstOrDefault();
                if (user == null)
                {
                    Test = -99;
                }
                else
                    Test = 1;
                return user;
            }
            catch (Exception)
            {
                Test = -99;
                user = null;
            }

            return user;
        }
        public TypeofCrops GetDetailsCrop(TypeofCrops cs)
        {

                var user = context.TypeofCrops.Where(p => p.CropId == cs.CropId).FirstOrDefault();
 
              return user;
        }
//To update investor personal details in user table
public bool UpdateInvestorUser(Users user)
        {
            bool status = false;
            Users user1 = context.Users.Find(user.UserName);
            try
            {
                if (user1 != null)
                {
                    user1.Name = user.Name;
                    user1.Address = user.Address;
                    user1.PhoneNumber = user.PhoneNumber;
                    context.SaveChanges();
                    status = true;
                    Test = 1;
                }
                else
                {
                    Test = -99;
                    status = false;

                }
            }
            catch (Exception)
            {
                Test = -99;
                status = false;
            }
            return status;
        }
        //To update buyer personal details in user table
        public bool UpdateBuyerUser(Users user)
        {
            bool status = false;
            Users user1 = context.Users.Find(user.UserName);
            try
            {
                if (user1 != null)
                {
                    user1.Name = user.Name;
                    user1.Address = user.Address;
                    user1.PhoneNumber = user.PhoneNumber;
                    context.SaveChanges();
                    status = true;
                    Test = 1;
                }
                else
                {
                    Test = -99;
                    status = false;

                }
            }
            catch (Exception)
            {
                Test = -99;
                status = false;
            }
            return status;
        }
        //To validate credentials of user login
        public byte? ValidateCredentials(string userId, string password)
        {
            Users user = context.Users.Find(userId);
            byte? roleId = null;
            if (user.UserPassword == password)
            {
                roleId = user.RoleId;
                if (userId == null)
                {
                    Test = -99;
                }
                else
                    Test = 1;
                return roleId;
            }
            else
            {
                Test = -99;
                roleId= null;
            }

            return roleId;
        }
        //To calculate return amount of investor 
        public double ReturnAmount(string Investorid, string cropId, string returnType)
        {
            double Returns;
            try
            {


                var obj3 = context.TypeofReturn.Find(cropId);
                var FixedReturn = obj3.FixedReturn;
                var profitsharing = obj3.ProfitSharing;
                var ProductMaterial = obj3.ProductMaterial;
                var obj = context.TypeofCrops.Find(cropId);
                var marketvalue = obj.MarketValue;
                var obj2 = context.Allocate.Where(p => p.InvestorId == Investorid).FirstOrDefault();
                var farmerid = obj2.FarmerId;
                var obj4 = context.Farmers.Where(p => p.FarmerId == farmerid).FirstOrDefault();
                var land = obj4.Land;
                var Totalproductioncost = obj4.TotalProductionCost;
                if (returnType == "Fixed Return")
                {
                    Returns = (double)Totalproductioncost + (double)FixedReturn * (double)Totalproductioncost / 100;
                }
                else if (returnType == "Profit sharing")
                {
                    Returns = (double)Totalproductioncost + (double)profitsharing * ((double)marketvalue * (double)land - (double)Totalproductioncost) / 100;
                }
                else
                {
                    Returns = ((double)ProductMaterial * (double)marketvalue / 100) * (double)land;
                }
                Investors investor = context.Investors.Find(Investorid);
                if (investor != null)
                {
                    investor.Returns = (decimal)Returns;
                    context.SaveChanges();

                }
            }
            catch (Exception)
            {

                throw;
            }

            return Returns;
        }
        //To allocate investor to a farmer
        public Allocate AllocationFunction(string username, string cropname)
        {
            Allocate a = new Allocate();

            var obj1 = context.Farmers.Where(p => (p.UserName == username) && (p.CropName == cropname)).FirstOrDefault();/*(from r in context.Farmers*/
            //            where ((r.UserName = username) && (r.CropId = cropid))
            /* select r).FirstOrDefault();*/
            var totalproductioncost = obj1.TotalProductionCost;
            var farmerid = obj1.FarmerId;
            var objectofallocate = context.Allocate.Where(p => p.FarmerId == farmerid).FirstOrDefault();

            if (objectofallocate == null)
            {
                //var investorid = (from c in context.Farmers
                //            join d in context.Investors on c.CropId equals d.CropId
                //            where (c.CropId == d.CropId && c.TotalProductionCost <= d.InvestmentAmount  )
                //            select d.InvestorId).ToString();
                var list = context.Investors
                              .Where(x => x.CropName == cropname)
                              .ToList();
                try
                {
                    foreach (var item in list)
                    {
                        if (item.InvestmentAmount >= totalproductioncost && item.CropName == cropname)
                        {

                            Allocate ob2 = null;
                              ob2= context.Allocate.Where(p => p.InvestorId == item.InvestorId).FirstOrDefault();
                            if (ob2 == null)
                            {
                                a.FarmerId = farmerid;
                                a.InvestorId = item.InvestorId;
                                context.Allocate.Add(a);
                                context.SaveChanges();
                                return a;
                            }
                            else
                            {
                                continue;
                            }
                          
                        }
                        else
                        {
                            a = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    var ab = ex.Message;
                    a = null;
                    return a;
                }


            }
            else
            {

                a.FarmerId = farmerid;
                a.InvestorId = objectofallocate.InvestorId;
            }
        
            return a;
        }
        //To validate admin login credentials
        public bool ValidateCredentAdmin(string userId, string password)
        {
            bool status = false;
            try
            {

                Admin user = context.Admin.Find(userId);

                if (user.Password == password)
                {
                    Test = 1;
                    status = true;
                }
            }

            catch
            {
                Test = -99;
                status = false;
            }


            return status;
        }
        //to fetch all investors registered in Agro farm
        public List<Users> GetInvestors()
        {
            try {
                var list = (from c in context.Users
                            where c.RoleId == 2
                            select c).ToList();
                Test = 1;
                return list;
            }
            catch
            {
                Test = -99;
            }
            return null;

        }

    //to fetch all farmers registered in Agro farm
    public List<Users> GetFarmers()
        {
            try
            {
                var list = (from c in context.Users
                            where c.RoleId == 1
                            select c).ToList();
                Test = 1;
                return list;
            }
            catch
            {
                Test = -99;
                return null;
            }

        }
        //to fetch all Types of crops available
        public List<TypeofCrops> Getcrops()
        {
            try
            {
                var list = (from c in context.TypeofCrops
                            select c).ToList();
                Test = 1;
                return list;
            }
            catch
            {
                Test = -99;
                return null;
            }


        }
        //to fetch returns of each crop 
        public List<TypeofReturn> GetReturn()
        {
            try
            {
                var returnList = (from e in context.TypeofReturn
                             select e).ToList();
                Test = 1;
                return returnList;

            }
            catch
            {
                Test = -99;
                return null;
            }



        }

        //Update changes in Type of Crops table
        public bool UpdateCrops(TypeofCrops crops)
        {
            bool status = false;
            TypeofCrops crop = context.TypeofCrops.Find(crops.CropId);
            try
            {
                if (crop != null)
                {
                    crop.ProductionCost = crops.ProductionCost;
                    crop.MarketValue = crops.MarketValue;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        //Update Returns of Type of return table
        public bool UpdateReturns(TypeofReturn re)
        {
            bool status = false;
            TypeofReturn ro = context.TypeofReturn.Find(re.CropId);
            try
            {
                if (ro != null)
                {
                    ro.FixedReturn = re.FixedReturn;
                    ro.ProfitSharing = re.ProfitSharing;
                    ro.ProductMaterial = re.ProductMaterial;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Add new crop details in typeofcrop table
        public bool AddNewCrop(TypeofCrops crop)
        {
            bool status = false;
            TypeofCrops crops = new TypeofCrops();
            crops.CropId = crop.CropId;
            crops.CropName = crop.CropName;
            crops.TimePeriod = crop.TimePeriod;
            crops.ProductionCost = crop.ProductionCost;
            crops.MarketValue = crop.MarketValue;
            crops.ImgData = "~/RegistrationImage/" +crop.ImgData;
            try
            {

                context.TypeofCrops.Add(crops);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Add new return details in typeofreturn table
        public bool AddNewReturn(TypeofReturn returns)
        {
            bool status = false;
            TypeofReturn return1 = new TypeofReturn();
            return1.CropId = returns.CropId;
            return1.FixedReturn = returns.FixedReturn;
            return1.ProfitSharing = returns.ProfitSharing;
            return1.ProductMaterial = returns.ProductMaterial;

            try
            {

                context.TypeofReturn.Add(return1);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        //To generate next crop id
        public string GetNextProductId()
        {
            string cropId = context.TypeofCrops.OrderByDescending(x => x.CropId).Select(x => x.CropId).FirstOrDefault().ToString();
            int id = Convert.ToInt32(cropId.Substring(1, cropId.Length - 1)) + 1;
            return "C" + id.ToString();
        }
        //public string GetNextBuyerId()
        //{
        //    string cropId = context.Buyers.OrderByDescending(x => x.BuyerId).Select(x => x.BuyerId).FirstOrDefault().ToString();
        //    int id = Convert.ToInt32(cropId.Substring(1, cropId.Length - 1)) + 1;
        //    return "B" + id.ToString();
        //}
        public bool AddKart(string cropId,string username,short quantity,string imgdata)
        {
            bool status = false;
            Kart c = new Kart();
            c.CropName = cropId;
            c.ImgData = imgdata;
            c.UserName = username;
            c.QuantityPurchased = quantity;
            try
            {

                context.Kart.Add(c);
                context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
                Console.WriteLine(e.Message);
            }
            return status;

        }
        public List<Kart> GetKart(string username)
        {
            try
            {
                var list = (from c in context.Kart
                            where c.UserName == username
                            select c).ToList();
                Test = 1;
                return list;
            }
            catch
            {
                Test = -99;
                return null;
            }

        }
        public Users GetImage(string username)
        {
            Users user = null;
            try
            {
                user = context.Users.Where(p => p.UserName == username).FirstOrDefault();
                if (user == null)
                {
                    Test = -99;
                }
                else
                    Test = 1;
                return user;
            }
            catch (Exception)
            {
                Test = -99;
                user = null;
            }

            return user;
        }
        public double Getpurchase(string username)
        {
            double totalamount = 0.0; 
            
             var list = (from c in context.Kart
                            where c.UserName == username
                            select c).ToList();
            foreach(var a in list)
            {
                var b = (from c in context.TypeofCrops
                         where c.CropName == a.CropName
                         select c).FirstOrDefault();
                totalamount = totalamount + (double)(a.QuantityPurchased * b.MarketValue);
            }
            return totalamount;
            
        }

        public bool Purchasecompletion(string username)
        {
            bool status = false;
            try
            {
                var deleteProducts = context.Kart.Where(p => p.UserName==username);
                foreach(var product in deleteProducts)
                {
                    Orders or = new Orders();
                    or.UserName = product.UserName;
                    or.CropName = product.CropName;
                    or.ImgData = product.ImgData;
                    or.QuantityPurchased = product.QuantityPurchased;
                    or.DateOfPurchase = DateTime.Now;
                    try
                    {
                        context.Orders.Add(or);
                        

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        throw;
                    }
                }
                context.Kart.RemoveRange(deleteProducts);
                context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        public bool CheckEmail(string emailId)
        {
            try
            {
                var user = context.Users.Find(emailId);
                if (user != null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

    }
}


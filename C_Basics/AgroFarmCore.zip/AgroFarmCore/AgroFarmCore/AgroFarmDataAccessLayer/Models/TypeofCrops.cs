﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class TypeofCrops
    {
        public string CropId { get; set; }
        public string CropName { get; set; }
        public string ImgData { get; set; }
        public decimal TimePeriod { get; set; }
        public decimal ProductionCost { get; set; }
        public decimal MarketValue { get; set; }
    }
}

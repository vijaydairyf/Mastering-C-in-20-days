﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Admin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Orders
    {
        public long OrderId { get; set; }
        public string UserName { get; set; }
        public string CropName { get; set; }
        public string ImgData { get; set; }
        public short QuantityPurchased { get; set; }
        public DateTime DateOfPurchase { get; set; }

        public Users UserNameNavigation { get; set; }
    }
}

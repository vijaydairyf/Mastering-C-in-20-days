﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Kart
    {
        public long KartId { get; set; }
        public string UserName { get; set; }
        public string CropName { get; set; }
        public string ImgData { get; set; }
        public short QuantityPurchased { get; set; }

        public Users UserNameNavigation { get; set; }
    }
}

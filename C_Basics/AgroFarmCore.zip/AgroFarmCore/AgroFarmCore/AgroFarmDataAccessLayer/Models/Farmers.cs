﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Farmers
    {
        public string FarmerId { get; set; }
        public string UserName { get; set; }
        public string CropName { get; set; }
        public decimal Land { get; set; }
        public decimal TotalProductionCost { get; set; }

        public Users UserNameNavigation { get; set; }
        public Allocate Allocate { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Investors
    {
        public string InvestorId { get; set; }
        public string UserName { get; set; }
        public string CropName { get; set; }
        public decimal InvestmentAmount { get; set; }
        public string ReturnType { get; set; }
        public decimal Returns { get; set; }

        public Users UserNameNavigation { get; set; }
        public Allocate Allocate { get; set; }
    }
}

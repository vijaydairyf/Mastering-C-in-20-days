﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Allocate
    {
        public string FarmerId { get; set; }
        public string InvestorId { get; set; }

        public Farmers Farmer { get; set; }
        public Investors Investor { get; set; }
    }
}

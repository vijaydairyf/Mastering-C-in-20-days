﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Buyers
    {
        public string BuyerId { get; set; }
        public string UserName { get; set; }
        public decimal PurchasingAmount { get; set; }
        public DateTime DateOfPurchase { get; set; }

        public Users UserNameNavigation { get; set; }
    }
}

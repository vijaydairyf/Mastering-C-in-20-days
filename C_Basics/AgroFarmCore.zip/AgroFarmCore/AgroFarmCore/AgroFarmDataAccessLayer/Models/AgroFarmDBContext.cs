﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class AgroFarmDBContext : DbContext
    {
        public AgroFarmDBContext()
        {
        }

        public AgroFarmDBContext(DbContextOptions<AgroFarmDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<Allocate> Allocate { get; set; }
        public virtual DbSet<Buyers> Buyers { get; set; }
        public virtual DbSet<Farmers> Farmers { get; set; }
        public virtual DbSet<Investors> Investors { get; set; }
        public virtual DbSet<Kart> Kart { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<TypeofCrops> TypeofCrops { get; set; }
        public virtual DbSet<TypeofReturn> TypeofReturn { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source =(localdb)\\mssqllocaldb;Initial Catalog=AgroFarmDB;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.HasKey(e => e.Username);

                entity.ToTable("admin");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Allocate>(entity =>
            {
                entity.HasKey(e => e.FarmerId);

                entity.ToTable("allocate");

                entity.HasIndex(e => e.InvestorId)
                    .HasName("UQ__allocate__41996EDF66519BDF")
                    .IsUnique();

                entity.Property(e => e.FarmerId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.InvestorId)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.HasOne(d => d.Farmer)
                    .WithOne(p => p.Allocate)
                    .HasForeignKey<Allocate>(d => d.FarmerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__allocate__Farmer__47DBAE45");

                entity.HasOne(d => d.Investor)
                    .WithOne(p => p.Allocate)
                    .HasForeignKey<Allocate>(d => d.InvestorId)
                    .HasConstraintName("FK__allocate__Invest__48CFD27E");
            });

            modelBuilder.Entity<Buyers>(entity =>
            {
                entity.HasKey(e => e.BuyerId);

                entity.Property(e => e.BuyerId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DateOfPurchase)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PurchasingAmount)
                    .HasColumnName("Purchasing amount")
                    .HasColumnType("numeric(10, 3)");

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.Buyers)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("fk_EmailI");
            });

            modelBuilder.Entity<Farmers>(entity =>
            {
                entity.HasKey(e => e.FarmerId);

                entity.Property(e => e.FarmerId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CropName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Land).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.TotalProductionCost).HasColumnType("numeric(10, 3)");

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.Farmers)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("FK__Farmers__UserNam__31EC6D26");
            });

            modelBuilder.Entity<Investors>(entity =>
            {
                entity.HasKey(e => e.InvestorId);

                entity.Property(e => e.InvestorId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CropName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.InvestmentAmount).HasColumnType("numeric(10, 3)");

                entity.Property(e => e.ReturnType)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Returns).HasColumnType("numeric(10, 3)");

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.Investors)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("FK__Investors__UserN__2E1BDC42");
            });

            modelBuilder.Entity<Kart>(entity =>
            {
                entity.ToTable("kart");

                entity.Property(e => e.CropName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ImgData)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.Kart)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("fk_Emai");
            });

            modelBuilder.Entity<Orders>(entity =>
            {
                entity.HasKey(e => e.OrderId);

                entity.Property(e => e.CropName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfPurchase)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ImgData)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("fk_Em");
            });

            modelBuilder.Entity<TypeofCrops>(entity =>
            {
                entity.HasKey(e => e.CropId);

                entity.Property(e => e.CropId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CropName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ImgData)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.MarketValue).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.ProductionCost).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.TimePeriod).HasColumnType("decimal(18, 0)");
            });

            modelBuilder.Entity<TypeofReturn>(entity =>
            {
                entity.HasKey(e => e.CropId);

                entity.Property(e => e.CropId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.FixedReturn).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ProductMaterial).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ProfitSharing).HasColumnType("numeric(18, 0)");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserName);

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ImgData)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);
            });

            modelBuilder.HasSequence("Sequence_Farmer").StartsAt(8);

            modelBuilder.HasSequence("sequence_invest");

            modelBuilder.HasSequence("Sequence_Investor").StartsAt(10);

            modelBuilder.HasSequence("sequence_Purchase");
        }
    }
}

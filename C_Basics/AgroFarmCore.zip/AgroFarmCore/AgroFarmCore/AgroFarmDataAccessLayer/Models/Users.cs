﻿using System;
using System.Collections.Generic;

namespace AgroFarmDataAccessLayer.Models
{
    public partial class Users
    {
        public Users()
        {
            Buyers = new HashSet<Buyers>();
            Farmers = new HashSet<Farmers>();
            Investors = new HashSet<Investors>();
            Kart = new HashSet<Kart>();
            Orders = new HashSet<Orders>();
        }

        public string UserName { get; set; }
        public string Name { get; set; }
        public string UserPassword { get; set; }
        public string ImgData { get; set; }
        public byte? RoleId { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public decimal PhoneNumber { get; set; }

        public ICollection<Buyers> Buyers { get; set; }
        public ICollection<Farmers> Farmers { get; set; }
        public ICollection<Investors> Investors { get; set; }
        public ICollection<Kart> Kart { get; set; }
        public ICollection<Orders> Orders { get; set; }
    }
}

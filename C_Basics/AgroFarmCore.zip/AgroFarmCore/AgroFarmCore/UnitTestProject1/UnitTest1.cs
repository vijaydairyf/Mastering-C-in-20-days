using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;


namespace UnitTestProject4
{
    [TestClass]
    public class UnitTest1
    {
        AgroFarmRepository repObj = new AgroFarmRepository();
        public UnitTest1()
        {

        }

        [TestMethod]//positive
        public void Add_Investor()
        {
            var expected = 1;

            repObj.Add_Investor("Abhai@gmail.com", "Rice", 12000, "ProfitSharing");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]//negative
        public void Add_Investor_Negative()
        {
            var expected = -99;

            repObj.Add_Investor("atul", "rice", 12000, "ProfitSharing");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]//positive
        public void Add_Farmer()
        {
            var expected = 1;
            repObj.Add_Farmer("diks@gmail.com", "Paddy", 50);
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//neagtive
        public void Add_Farmer_Negative()
        {
            var expected = -99;
            repObj.Add_Farmer("deep@yahoo.com", "Paddy", 5);
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
   /*     [TestMethod]*///positive
        //public void Add_User()
        //{
        //    var expected = 1;

        //    repObj.Add_User("atul@gmail.com", "atul", "Atul!123", "1", "M", "HudsonBay", 9089765098);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);

        //}
        //[TestMethod]//negative
        //public void Add_User_Negative()
        //{
        //    var expected = -99;

        //    repObj.Add_User("atul123", "atul", "atul@123", "1", "M", "Hudson Bay", 9089765098);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);

        //}
        [TestMethod]//positive
        public void GetAllDetails()
        {
            var expected = 1;
            repObj.GetAllDetails("dabc@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//neagtive
        public void GetAllDetails_Negative()
        {
            var expected = -99;
            repObj.GetAllDetails("cd@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]//positive
        public void GetFarmerDetails()
        {
            var expected = 1;
            repObj.GetFarmerDetails("diks@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//negative
        public void GetFarmerDetails_Negative()
        {
            var expected = -99;
            repObj.GetFarmerDetails("dbc@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        //[TestMethod]//positive
        //public void UpdateFarmerUser()
        //{
        //    var expected = 1;
        //    repObj.UpdateFarmerUser("Aman", "Baker Street", 9876509876);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);
        //}
        //[TestMethod]//neagtive
        //public void UpdateFarmerUser_Negative()
        //{
        //    var expected = -99;
        //    repObj.UpdateFarmerUser("Aman", "Baker Street", 9876509876);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);
        //}

        [TestMethod]//positive
        public void GetAllInvestors()
        {
            var expected = 1;
            repObj.GetAllInvestors("aman@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//neagtive
        public void GetAll_Negative()
        {
            var expected = -99;
            repObj.GetAllInvestors("iua@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]//postive
        public void GetInvestorDetails()
        {
            var expected = 1;
            repObj.GetInvestorDetails("aman@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//negative
        public void GetInvestorDetails_Negative()
        {
            var expected = -99;
            repObj.GetInvestorDetails("ayta@gmail.com");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        //[TestMethod]//positive
        //public void UpdateInvestorUser()
        //{
        //    var expected = 1;
        //    repObj.UpdateInvestorUser("aba@gmail.com","Kamal", "Hudson Bay", 7865409422);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);
        //}
        //[TestMethod]//neagtive
        //public void UpdateInvestorUser_Negative()
        //{
        //    var expected = -99;
        //    repObj.UpdateInvestorUser("auio@gmail.com", "Kamal", "Hudson Bay", 7865409422);
        //    var actual = repObj.Test;
        //    Assert.AreEqual(expected, actual);
        //}
        [TestMethod]//positive//USERLOGIN
        public void ValidateCredentials()
        {
            var expected = 1;
            repObj.ValidateCredentials("aman@gmail.com", "Aman!10.");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//negative
        public void ValidateCredentials_Negative()
        {
            var expected = -99;
            repObj.ValidateCredentials("diks@gmail.com", "D1!po4tu");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//postive//ADMINLOGIN
        public void ValidateCredentAdmin()
        {
            var expected = 1;
            repObj.ValidateCredentAdmin("admin", "admin@123");
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//positive
        public void GetInvestors()
        {
            var expected = 1;
            repObj.GetInvestors();
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//positive
        public void GetFarmers()
        {
            var expected = 1;
            repObj.GetFarmers();
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//positive
        public void Getcrops()
        {
            var expected = 1;
            repObj.Getcrops();
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]//positive
        public void GetReturn()
        {
            var expected = 1;
            repObj.GetReturn();
            var actual = repObj.Test;
            Assert.AreEqual(expected, actual);
        }
    }
}


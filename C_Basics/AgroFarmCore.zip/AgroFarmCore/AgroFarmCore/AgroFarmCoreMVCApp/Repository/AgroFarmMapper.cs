﻿using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace AgroFarmCoreMVCApp.Repository
{
    public class AgroFarmMapper:Profile
    {
        public AgroFarmMapper()
        {
            CreateMap<Models.Investors, Investors>();
            CreateMap<Investors, Models.Investors>();
            CreateMap<Models.Users, Users>();
            CreateMap<Users, Models.Users>();
            CreateMap<Models.Farmers, Farmers>();
            CreateMap<Farmers,Models.Farmers>();
            CreateMap<Allocate, Models.Allocate>();
            CreateMap<Models.Allocate, Allocate>();
            CreateMap<Models.TypeofCrops, TypeofCrops>();
            CreateMap<TypeofCrops, Models.TypeofCrops>();
            CreateMap<Models.TypeofReturn, TypeofReturn>();
            CreateMap<TypeofReturn, Models.TypeofReturn>();
            CreateMap<Models.TypeofCrops, TypeofCrops>();
            CreateMap<TypeofCrops, Models.TypeofCrops>();
            CreateMap<Models.Kart, Kart>();
            CreateMap<Kart, Models.Kart>();

        }
    }
}

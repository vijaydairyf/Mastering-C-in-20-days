﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using AutoMapper.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AgroFarmCoreMVCApp.Controllers
{
    public class BuyersController : Controller
    {
        private readonly IMapper _mapper;
        //  IConfiguration configuration;
        private readonly AgroFarmRepository _repObj;
        public BuyersController(IMapper mapper, AgroFarmRepository repObj)
        {
            // this.configuration = configuration;
            _mapper = mapper;
            _repObj = repObj;

        }
        // GET: /<controller>/
        public IActionResult BuyerHome()
        {
            var userid = HttpContext.Session.GetString("username");
            var lstEntityProducts = _repObj.GetImage(userid);
            var x = _mapper.Map<Models.Users>(lstEntityProducts);
            HttpContext.Session.SetString("Img", x.ImgData);
            HttpContext.Session.SetString("name", x.Name);
            Dictionary<string, string> data = new Dictionary<string, string>();
            string[] key = { "paddy", "Wheat", "Jowar", "Bajra", "Mushroom", "Maize" };
            string[] value = { "250/kg", "350/Kg", "300/Kg", "150/Kg", "470/Kg", "330/Kg" };
            for (int i = 0; i < 6; i++)
            {
                data.Add(key[i], value[i]);
            }
            ViewBag.TopProducts = data;
            return View();
            
        }
        public IActionResult viewItem(TypeofCrops cs)
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                var lstEntityProducts = _repObj.GetDetailsCrop(_mapper.Map<TypeofCrops>(cs));
                var x = _mapper.Map<Models.TypeofCrops>(lstEntityProducts);
                HttpContext.Session.SetString("cropId",x.CropName);
                HttpContext.Session.SetString("Img", x.ImgData);
                return View(x);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult SaveKart(IFormCollection frm, TypeofCrops cs)
        {
            bool status = false;
            //string buyerId = _repObj.GetNextBuyerId();
            string qunatity = frm["Quantity"];
            short qunt = Convert.ToInt16(qunatity);
            var username = HttpContext.Session.GetString("username");
            string cropId = HttpContext.Session.GetString("cropId");
            string image = HttpContext.Session.GetString("Img");
            try
            {
                status = _repObj.AddKart(cropId, username, qunt, image);
                if (status)
                    return RedirectToAction("ViewKart");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }

        }
        public IActionResult ViewPersonalDetails()
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                var lstEntityProducts = _repObj.GetFarmerDetails(username);
                var x = _mapper.Map<Models.Users>(lstEntityProducts);
                return View(x);
            }
            catch (Exception)
            {

                return View("Error");
            }

        }

        public IActionResult UpdateBuyerDetails(Models.Users user)
        {
            return View(user);
        }

        public IActionResult SaveUpdatedDetails(Models.Users user)
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                bool status = false;

                try
                {
                    status = _repObj.UpdateBuyerUser(_mapper.Map<Users>(user));
                    if (status)
                        return RedirectToAction("ViewPersonalDetails");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }


            }
            catch (Exception)
            {
                return View("Error");
            }
        }


        public IActionResult ViewProducts()
        {
            //var userid = HttpContext.Session.GetString("username");
            //if (userid == null)
            //{
            //    return RedirectToAction("Login", "Home");
            //}
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                var lstEntityProducts = _repObj.Getcrops();
                List<Models.TypeofCrops> lstModelProducts = new List<Models.TypeofCrops>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.TypeofCrops>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }

        }
        public IActionResult ViewKart()
        {
            var username = HttpContext.Session.GetString("username");
            if (username == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var userid = HttpContext.Session.GetString("username");
            string totalamount = Convert.ToString(_repObj.Getpurchase(userid));
            HttpContext.Session.SetString("purchaseamount",totalamount);
            //if (userid == null)
            //{
            //    return RedirectToAction("Login", "Home");
            //}
            try
            {
                var lstEntityProducts = _repObj.GetKart(userid);
                if(lstEntityProducts.Count()==0)
                {
                    return View("EmptyKart");
                }
                List<Models.Kart> lstModelProducts = new List<Models.Kart>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.Kart>(product));
                   
                }
               
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }

           
        }
        public IActionResult Checkout()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public IActionResult Purchasesuccessful()
        {
            bool status = false;
            var username = HttpContext.Session.GetString("username");
            if (username == null)
            {
                return RedirectToAction("Login", "Home");
            }
            status = _repObj.Purchasecompletion(username);
            if (status)
                return View();
            else
                return View("Error");
        }
           


    }
}

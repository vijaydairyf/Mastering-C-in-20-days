﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AgroFarmCoreMVCApp.Repository;
using AutoMapper;
using AgroFarmDataAccessLayer;
using Microsoft.AspNetCore.Http;
using AgroFarmDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AgroFarmCoreMVCApp.Controllers
{
    public class InvestorsController : Controller
    {
        private readonly IMapper _mapper;
        IConfiguration configuration;
        private readonly AgroFarmRepository _repObj;
        public InvestorsController(IConfiguration configuration, IMapper mapper, AgroFarmRepository repObj)
        {
            this.configuration = configuration;
            _mapper = mapper;
            _repObj = repObj;

        }
        // GET: /<controller>/
        public IActionResult InvestorHome()
        {
            var userid = HttpContext.Session.GetString("username");
            var lstEntityProducts = _repObj.GetImage(userid);
            var x = _mapper.Map<Models.Users>(lstEntityProducts);
            HttpContext.Session.SetString("Img", x.ImgData);
            HttpContext.Session.SetString("name", x.Name);
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        public IActionResult ViewProducts()
        {
            
           
            //var userid = TempData["username"].ToString();
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var lstEntityProducts = _repObj.GetAllInvestors(userid);

            List<Models.Investors> lstModelProducts = new List<Models.Investors>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Investors>(product));
            }
            return View(lstModelProducts);
        }
        public IActionResult AddProduct()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            List<TypeofCrops> li = _repObj.Getcrops();
            List<string> listCrop = new List<string>();
            foreach (var item in li)
            {
                listCrop.Add(item.CropName);
            }
            ViewBag.lstEntityProducts = listCrop;
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        public IActionResult SaveAddedProduct(IFormCollection frm, Models.Investors Investor)
        {
            try
            {
            
                string cropName = frm["cropName"];
                string returnType = frm["Return"];
                //var username = TempData["username"].ToString();
                var username = HttpContext.Session.GetString("username");
                bool status = false;
                if (ModelState.IsValid)
                {
                    try
                    {
                        status = _repObj.Add_Investor(username, cropName, Investor.InvestmentAmount, returnType);
                        if (status)
                            return RedirectToAction("ViewProducts");
                        else
                            return View("Error");
                    }
                    catch (Exception)
                    {
                        return View("Error");
                    }
                }
                return View("AddProduct", Investor);
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        public IActionResult ViewUsers()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                //  var username = TempData["username"].ToString();
                var username = HttpContext.Session.GetString("username");
                var lstEntityProducts = _repObj.GetInvestorDetails(username);
                var x = _mapper.Map<Models.Users>(lstEntityProducts);
                return View(x);
            }
            catch (Exception)
            {
                return View("Error");
            }

        }

        public IActionResult UpdateInvestorDetails(Models.Users user)
        {
            return View(user);
        }
        public IActionResult SaveUpdateDetails(Models.Users user)
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                bool status = false;

                try
                {
                    status = _repObj.UpdateInvestorUser(_mapper.Map<Users>(user));
                    if (status)
                        return RedirectToAction("ViewUsers");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }


            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        //public IActionResult ReturnAmount()
        //{
        //    var Amount=_re
        //}



        //public IActionResult ViewEntries()
        //{
        //    try
        //    {
        //        ServiceRepository serviceRepository = new ServiceRepository(configuration);
        //        HttpResponseMessage response = serviceRepository.GetResponse("api/Product/");
        //        response.EnsureSuccessStatusCode();
        //        List<Models.Investors> products = response.Content.ReadAsAsync<List<Models.Investors>>().Result;
        //        return View(products);
        //    }
        //    catch (Exception ex)
        //    {
        //        return View("Error");
        //    }
        ////}
        //public IActionResult
        //public IActionResult Index()
        //{
        //    try
        //    {
        //        ServiceRepository serviceRepository = new ServiceRepository(configuration);
        //        HttpResponseMessage response = serviceRepository.GetResponse("api/Investors/GetInvestors");
        //        response.EnsureSuccessStatusCode();
        //        List<Models.Investors> products = response.Content.ReadAsAsync<List<Models.Investors>>().Result;
        //        return View(products);
        //    }

        //    catch (Exception ex)
        //    {
        //        var a = ex.Message;
        //        return View("Error");
        //    }
        //}

        public IActionResult Details(Models.Investors obj)
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                HttpContext.Session.SetString("cropid", obj.CropName);
                HttpContext.Session.SetString("investorid", obj.InvestorId);
                HttpContext.Session.SetString("returntype", obj.ReturnType);
                //TempData["cropid"] = obj.CropId;
                //TempData["investorid"] = obj.InvestorId;
                //TempData["returntype"] = obj.ReturnType;
                return View(obj);
            }
            catch (Exception)
            {
                return View("Error");
            }

        }
        public IActionResult ReturnAmount()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                string cropid = HttpContext.Session.GetString("cropid");
                string investorid = HttpContext.Session.GetString("investorid");
                string returnType = HttpContext.Session.GetString("returntype");
                double Returns = _repObj.ReturnAmount(investorid, cropid, returnType);
                TempData["returns"] = Returns;
                return View();
            }
            catch (Exception)
            {


                return View("InvestingError");
            }

        }
        public IActionResult ViewProcess()
        {
            try
            {
                return View("ViewProcess");
            }
            catch(Exception)
            {
                return View("Error");
            }
        }
    }

}


﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
//using AgroFarmCoreMVCApp.Models;
using AgroFarmDataAccessLayer.Models;
using AgroFarmDataAccessLayer;
using AutoMapper;
using AgroFarmCoreMVCApp.Models;

namespace AgroFarmCoreMVCApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly AgroFarmRepository _repObj;
        private readonly IMapper _mapper;
        public HomeController(IMapper mapper,AgroFarmRepository repObj)
        {
            _repObj = repObj;
            mapper =_mapper;
        }
        public IActionResult CheckRole(IFormCollection frm)
        {
            try
            {
               
                string userId = frm["name"];
                //TempData["username"] = userId;
                string password = frm["pwd"];
                //string checkbox = frm["RememberMe"];
                //if (checkbox == "on")
                //{
                //    CookieOptions option = new CookieOptions();
                //    option.Expires = DateTime.Now.AddDays(1);
                //    Response.Cookies.Append("UserId", userId, option);
                //    Response.Cookies.Append("Password", password, option);
                //}
                string username1 = userId.Split('@')[0];
                byte? roleId = _repObj.ValidateCredentials(userId, password);
                if (roleId == 1)
                {
                    
                    HttpContext.Session.SetString("username", userId);
                    return RedirectToAction("FarmerHome", "Farmers");
                }
                else if (roleId == 2)
                {
                    HttpContext.Session.SetString("username", userId);
					//HttpContext.Session.SetString("username2", username1);
                    return RedirectToAction("InvestorHome", "Investors");
                }
                else if(roleId==3)
                {
                    HttpContext.Session.SetString("username", userId);
                    //HttpContext.Session.SetString("username2", username1);
                    return RedirectToAction("BuyerHome", "Buyers");
                }
                return View("Login");
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                ViewBag.LoginDetails = "User name or password doesn't match";
                return View("Login");
            }
           
        }
        public IActionResult Login()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
   public IActionResult Logout()
        {
            HttpContext.Session.Remove("username");
         
            HttpContext.Session.Clear();
            

            return RedirectToAction("Login", "Home");
        }
        public IActionResult Index()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }
      
        public IActionResult Privacy()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

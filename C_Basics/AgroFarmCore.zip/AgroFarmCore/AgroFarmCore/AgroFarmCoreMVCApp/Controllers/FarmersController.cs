﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using AutoMapper.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AgroFarmCoreMVCApp.Controllers
{
    public class FarmersController : Controller
    {
        private readonly IMapper _mapper;
        //  IConfiguration configuration;
        private readonly AgroFarmRepository _repObj;
        public FarmersController(IMapper mapper, AgroFarmRepository repObj)
        {
            // this.configuration = configuration;
            _mapper = mapper;
            _repObj = repObj;

        }

        // GET: /<controller>/
        public IActionResult FarmerHome()
        {
            var userid = HttpContext.Session.GetString("username");
            var lstEntityProducts = _repObj.GetImage(userid);
            var x = _mapper.Map<Models.Users>(lstEntityProducts);
            HttpContext.Session.SetString("Img", x.ImgData);
            HttpContext.Session.SetString("name",x.Name);
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            return View();
        }
        public IActionResult ViewFarmers()
        {
           
            try
            { 
                var userid = HttpContext.Session.GetString("username");
                if (userid == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                var lstEntityProducts = _repObj.GetAllDetails(userid);
                List<Models.Farmers> lstModelProducts = new List<Models.Farmers>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.Farmers>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult Addfarmer()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            List<TypeofCrops> li = _repObj.Getcrops();
            List<string> listCrop = new List<string>();
            foreach (var item in li)
            {
                listCrop.Add(item.CropName);
            }
            ViewBag.lstEntityProducts = listCrop;
            try
            {
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult SaveAddedFarmer(IFormCollection frm, Models.Farmers farmer)
        {
            try
            {
                string cropName = frm["cropname"];
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                bool status = false;
                if (ModelState.IsValid)
                {
                    try
                    {
                        status = _repObj.Add_Farmer(username,cropName, farmer.Land);
                        if (status)
                            return RedirectToAction("ViewFarmers");
                        else
                            return View("Error");
                    }
                    catch (Exception)
                    {
                        return View("Error");
                    }
                }
                return View("Addfarmer", farmer);
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        public IActionResult ViewPersonalDetails()
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                var lstEntityProducts = _repObj.GetFarmerDetails(username);
                var x = _mapper.Map<Models.Users>(lstEntityProducts);
                return View(x);
            }
            catch (Exception)
            {

                return View("Error");
            }

        }

        public IActionResult allocate(Models.Farmers obj)
        {
            try
            {
                //HttpContext.Session.SetString("cropid", obj.CropId);
                //HttpContext.Session.SetString("username", obj.UserName);
                var objofallocate = _repObj.AllocationFunction(obj.UserName, obj.CropName);
                var objofallocateinmvc = _mapper.Map<Models.Allocate>(objofallocate);
                if (objofallocateinmvc != null)
                {

                    return View(objofallocateinmvc);
                }
                else
                {
                    return View("AllocationError");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }


        }
        public IActionResult UpdateFarmerDetails(Models.Users user)
        {
            return View(user);
        }
        public IActionResult SaveUpdateDetails(Models.Users user)
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                if (username == null)
                {
                    return RedirectToAction("Login", "Home");
                }
                bool status = false;
      
                    try
                    {
                        status = _repObj.UpdateFarmerUser(_mapper.Map<Users>(user));
                        if (status)
                            return RedirectToAction("ViewPersonalDetails");
                        else
                            return View("Error");
                    }
                    catch (Exception)
                    {
                        return View("Error");
                    }
                
               
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
    }
}

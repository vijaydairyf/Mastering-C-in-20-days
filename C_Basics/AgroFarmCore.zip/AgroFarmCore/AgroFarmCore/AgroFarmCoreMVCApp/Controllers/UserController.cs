﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AgroFarmCoreMVCApp.Models;
using AgroFarmDataAccessLayer.Models;
using AgroFarmDataAccessLayer;
using Classproject;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AgroFarmCoreMVCApp.Controllers
{
    public class UserController : Controller
    {
        private readonly AgroFarmRepository _repObj;
        public UserController(AgroFarmRepository repObj)
        {
            _repObj = repObj;
        }

        // GET: /<controller>/
        public IActionResult RegisterUser()
        {
            //List<string> list = new List<string>();
            //list.Add("Farmers");
            //list.Add("Investors");
            //list.Add("Buyers");
            //ViewBag.RoleList = list;
            
                return View();
            
        }
        public IActionResult SaveRegisterUser(Models.Users userObj, IFormCollection frm)
        {
            try
            {
                string Role = frm["role"];
                bool emailexist = _repObj.CheckEmail(userObj.UserName);
                if (emailexist)
                {
                    bool status = _repObj.Add_User(userObj.UserName, userObj.Name, userObj.UserPassword, userObj.ImgData, Role, userObj.Gender, userObj.Address, userObj.PhoneNumber);
                    if (status)
                    {
                        TempData["Message"] = "successfulregister";
                        ViewData["Message"] = "Your contact page.";
                        Class1 ob = new Class1();
                        ob.sendEMailThroughOUTLOOK(userObj.UserName, userObj.Name);
                        return RedirectToAction("Login", "Home");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                else
                {
                    TempData["Message"] = "emailexist";
                    return Redirect("RegisterUser");

                }

            }
            catch (Exception)
            {
                return View("Error");
            }

        }


    }
}

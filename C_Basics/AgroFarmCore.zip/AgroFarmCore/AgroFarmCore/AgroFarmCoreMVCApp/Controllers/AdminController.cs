﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgroFarmDataAccessLayer;
using AgroFarmDataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AgroFarmCoreMVCApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly AgroFarmRepository _repObj;
        private readonly IMapper _mapper;
        public AdminController(IMapper mapper, AgroFarmRepository repObj)
        {
            _repObj = repObj;
            _mapper = mapper;
        }
        public IActionResult AdminHome()
        {
            var userid = HttpContext.Session.GetString("username");
            if(userid==null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        public IActionResult LoginAdmin()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        // GET: /<controller>/
        public IActionResult Check(IFormCollection frm)
        {

            string userId = frm["name"];
            string password = frm["pwd"];
            HttpContext.Session.SetString("username", userId);
            bool status = _repObj.ValidateCredentAdmin(userId, password);
            if (status == true)
            {
                return RedirectToAction("AdminHome", "Admin");
            }

            return View();


        }
        public IActionResult ViewFarmers()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                var lstEntityProducts = _repObj.GetFarmers();
                List<Models.Users> lstModelProducts = new List<Models.Users>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.Users>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult ViewInvestors()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                var lstEntityProducts = _repObj.GetInvestors();
                List<Models.Users> lstModelProducts = new List<Models.Users>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.Users>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult ViewCrops()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                var lstEntityProducts = _repObj.Getcrops();
                List<Models.TypeofCrops> lstModelProducts = new List<Models.TypeofCrops>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.TypeofCrops>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult ViewReturns()
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            try
            {
                var lstEntityProducts = _repObj.GetReturn();
                List<Models.TypeofReturn> lstModelProducts = new List<Models.TypeofReturn>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.TypeofReturn>(product));
                }
                return View(lstModelProducts);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult UpdateCrops(Models.TypeofCrops crop)
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            return View(crop);

        }

        public IActionResult SaveUpdatedCrop(Models.TypeofCrops crop)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = _repObj.UpdateCrops(_mapper.Map<TypeofCrops>(crop));
                    if (status)
                        return RedirectToAction("ViewCrops");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateCrops", crop);
        }
        public IActionResult UpdateReturn(Models.TypeofReturn returns)
        {
            var userid = HttpContext.Session.GetString("username");
            if (userid == null)
            {
                return RedirectToAction("Login", "Home");
            }
            return View(returns);

        }

        public IActionResult SaveUpdatedReturns(Models.TypeofReturn returns)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = _repObj.UpdateReturns(_mapper.Map<TypeofReturn>(returns));
                    if (status)
                        return RedirectToAction("ViewReturns");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateReturns", returns);
        }
        public IActionResult AddNewCrop(Models.TypeofCrops crop)
        {
            try
            {
                string cropId = _repObj.GetNextProductId();
                ViewBag.NextCropId = cropId;
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
            
            return View(crop);
        }

        public IActionResult SaveAddedCrop(Models.TypeofCrops crop)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = _repObj.AddNewCrop(_mapper.Map<TypeofCrops>(crop));
                    if (status)
                        return RedirectToAction("ViewCrops");
                    else
                        return View("Error");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return View("Error");
                }
            }
            return View("AddNewCrop", crop);
        }

        public IActionResult AddNewReturns(Models.TypeofReturn returns)
        {
            string cropId = _repObj.GetNextProductId();
            ViewBag.NextCropId = cropId;
            return View(returns);
        }

        public IActionResult SaveAddedReturn(Models.TypeofReturn returns)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = _repObj.AddNewReturn(_mapper.Map<TypeofReturn>(returns));
                    if (status)
                        return RedirectToAction("ViewReturns");
                    else
                        return View("Error");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return View("Error");
                }
            }
            return View("AddNewReturns", returns);
        }

    }
}

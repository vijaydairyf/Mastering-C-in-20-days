﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AgroFarmCoreMVCApp.Models
{
    public class Farmers
    {
        public string FarmerId { get; set; }
        public string UserName { get; set; }

        public string CropName { get; set; }
        [Required(ErrorMessage = "Land is mandatory.")]
        public decimal Land { get; set; }

        public decimal TotalProductionCost { get; set; }

    }
}

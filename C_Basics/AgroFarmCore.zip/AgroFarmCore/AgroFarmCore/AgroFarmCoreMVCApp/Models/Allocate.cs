﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgroFarmCoreMVCApp.Models
{
    public class Allocate
    {
        public string FarmerId { get; set; }
        public string InvestorId { get; set; }
    }
}

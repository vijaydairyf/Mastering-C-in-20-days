﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgroFarmCoreMVCApp.Models
{
    public class Buyers
    {
        public string BuyerId { get; set; }
        public string UserName { get; set; }
        public decimal PurchasingAmount { get; set; }
        public DateTime DateOfPurchase { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel;


namespace AgroFarmCoreMVCApp.Models
{
    public class Users
    {
        [DisplayName("User Name")]
        [Required(ErrorMessage = "User Name is mandatory.")]
        //[RegularExpression(ErrorMessage = "Enter a valid UserId")]
        
        public string UserName { get; set; }

        
        [RegularExpression("^[a-zA-Z]+(\\s[a-zA-Z]+)?$", ErrorMessage = "Invalid Name")]
        [StringLength(maximumLength: 20,ErrorMessage ="Name too long . Only 20 characters are allowed")]
        [Required(ErrorMessage = "Name is mandatory.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "User Password is mandatory.")]
        [DisplayName("User Password")]
        public string UserPassword { get; set; }

        public string ImgData { get; set; }

        [Required(ErrorMessage = "Role is mandatory.")]
        public byte? RoleId { get; set; }

        [Required(ErrorMessage = "Gender is mandatory.")]
        [RegularExpression("M|F", ErrorMessage = "Gender should be M or F")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Address is mandatory.")]
        [RegularExpression(@"^[a-zA-Z]+(\s[a-zA-Z]+)?$", ErrorMessage = "Invalid Address")]
        [StringLength(maximumLength: 50, ErrorMessage = "Address too long . Only 50 characters are allowed")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Phone Number is mandatory.")]
         [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid Mobile Number")]
          public decimal PhoneNumber { get; set; }
    }
}

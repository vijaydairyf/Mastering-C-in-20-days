﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgroFarmCoreMVCApp.Models
{
    public class TypeofReturn
    { 
    public string CropId { get; set; }
    public decimal FixedReturn { get; set; }
    public decimal ProfitSharing { get; set; }
    public decimal ProductMaterial { get; set; }
    
    }
}

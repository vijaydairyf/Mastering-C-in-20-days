﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Classproject
{
    public class Class1
    {
        public void sendEMailThroughOUTLOOK(string emailId,string name)
        {
            
            
            try
            {
                // Create the Outlook application.
                Outlook.Application oApp = new Outlook.Application();
                // Create a new mail item.
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                // Set HTMLBody. 
                //add the body of the email
                oMsg.HTMLBody = "Hi "+ name + "," + "<html><Body><br><strong>Welcome to our Agro Farm. You are successfully registered!!</strong> <br> <img src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgQRoqLqvK3fDj_dANualfZCKH-D_cvybcccJ_8AUQRtWQCw7iTw\"><br>Grow your money by helping our farmers. It's an opportunity to directly impact the lives of farmers and help them to live a better life.<br><br><br>Regards,<br>Agro Farm and Team</body></html>";

                //Subject line
                oMsg.Subject = "Welcome in AgroFarm";
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                // Change the recipient in the next line if necessary.
                Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add(emailId);
                oRecip.Resolve();
                // Send.
                oMsg.Send();
                // Clean up.
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;
            }//end of try block
            catch (Exception ex)
            {
            }//end of catch
        }//end of Email Method

    }
}

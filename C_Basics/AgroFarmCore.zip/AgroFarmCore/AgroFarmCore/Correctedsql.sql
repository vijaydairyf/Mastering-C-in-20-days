CREATE DATABASE AgroFarmDB
GO
USE AgroFarmDB
GO
drop database  AgroFarmDB
--drop table Users

IF OBJECT_ID('Users')  IS NOT NULL
Drop TABLE Users
GO
IF OBJECT_ID('Farmers')  IS not  NULL
DROP TABLE Farmers
GO
IF OBJECT_ID('Buyers')  IS  NULL
DROP TABLE Buyers
GO
IF OBJECT_ID('Investors')  IS not NULL
DROP TABLE Investors
GO
IF OBJECT_ID('TypeofCrops')  IS not  NULL
DROP TABLE TypeofCrops
GO
IF OBJECT_ID('usp_RegisterUser')  IS NOT NULL
DROP PROC usp_RegisterUser
GO
create TABLE Users
(
	[UserName] VARCHAR(50) primary key constraint chk_email check ([UserName]like '%_@_%_.___') ,
	[Name] varchar(20)  CHECK(Len([Name])<=20),
	[UserPassword] VARCHAR(8) check([UserPassword]like '%[0-9]%' and [UserPassword] like '%[a-z]%' and [UserPassword] like'%[!@#$%a^&()-_+=.,;:"`~]%' and len([UserPassword] )>= 8 and len([UserPassword] )< 15)  NOT NULL,
    [RoleId] Tinyint ,
	[Gender] CHAR CONSTRAINT chk_Gender CHECK(Gender='F' OR Gender='M') NOT NULL,
	[Address] VARCHAR(200)  CHECK(Len([Address])<=200) NOT NULL,
	[PhoneNumber] NUMERIC(10) check([PhoneNumber] like '%[0-9]%' and len([PhoneNumber])=10) not null
)
insert into users values('diks.batra111@gmail.com','John','Aman!10.',1,'M','Delhi',9955664321)
insert into users values('aba@gmail.com','John','Ba654!19',3,'M','Delhi',9955664321)
--insert into users values('nami@gmail.com','Nami','nami!Man',1,'M','Delhi',9955664321)

--drop table Users

select * from users
select * from kart
delete From Kart where CropId ='C1'
	CREATE TABLE TypeofCrops
(
   [CropId] CHAR(4) CONSTRAINT pk_CropId PRIMARY KEY CONSTRAINT chk_CropId CHECK(CropId LIKE 'C%'),
    [CropName] varchar(20) ,
	[TimePeriod] decimal NOT NULL,
	[ProductionCost] decimal NOT NULL,
	[MarketValue] decimal NOT NULL
)

CREATE TABLE Investors
(
    [InvestorId] CHAR(4) CONSTRAINT pk_InvestorId PRIMARY KEY,
	[UserName] VARCHAR(50) references Users(UserName),
	[CropId]  CHAR(4)  NOT NULL references  TypeofCrops(CropId),
    [InvestmentAmount] Numeric(10,3) check([InvestmentAmount]<1000000 )NOT NULL,
	[ReturnType] Varchar(20) NOT NULL,
	[Returns] Numeric(10,3) NOT NULL

)
insert into Investors values('I21','aba@gmail.com','C1',4000,'Fixed Return','0')

CREATE TABLE Farmers
(
    [FarmerId] CHAR(4) CONSTRAINT pk_FarmerId PRIMARY KEY,
	[UserName] VARCHAR(50) references Users(UserName),
	[CropId] CHAR(4)  NOT NULL references  TypeofCrops(CropId),
    [Land] decimal NOT NULL check([Land]<1000),
	 [TotalProductionCost] Numeric(10,3) NOT NULL
	)


create TABLE TypeofReturn
(
[CropId] CHAR(4) CONSTRAINT pk_CropI PRIMARY KEY CONSTRAINT chk_C CHECK(CropId LIKE 'C%'),
[FixedReturn] Numeric NOT NULL,
[ProfitSharing] Numeric NOT NULL,
[ProductMaterial] Numeric NOT NULL
   
)
create table kart
(
BuyerId  CHAR(4) NOT NULL primary key,
[UserName] VARCHAR(50) CONSTRAINT fk_Emai REFERENCES Users(UserName),
[CropId] CHAR(4) references Typeofcrops(CropId),
[QuantityPurchased] SMALLINT CONSTRAINT chk_QuantityPurchase CHECK(QuantityPurchased>0) NOT NULL,
)
CREATE TABLE Buyers
(
[PurchaseId]  BIGINT CONSTRAINT pk_Purchase PRIMARY KEY IDENTITY(1000,1),
[BuyerId] CHAR(4) NOT NULL references kart(BuyerId),
[UserName] VARCHAR(50) CONSTRAINT fk_EmailI REFERENCES Users(UserName),
[Purchasing amount] Numeric(10,3) NOT NULL,
[DateOfPurchase] DATETIME CONSTRAINT chk_DateOfPurch CHECK(DateOfPurchase<=GETDATE()) DEFAULT GETDATE() NOT NULL
)


--CREATE TABLE PurchaseDetails
--(
--	[Purchase] BIGINT CONSTRAINT pk_PurchaseId PRIMARY KEY IDENTITY(1000,1),
--	[UserName] VARCHAR(25) CONSTRAINT fk_EmailId REFERENCES Users(UserName),
--	[CropId] CHAR(4) CONSTRAINT fk_ProductId REFERENCES TypeofCrops(CropId),
--	[QuantityPurchased] SMALLINT CONSTRAINT chk_QuantityPurchased CHECK(QuantityPurchased>0) NOT NULL,
--)

create table allocate
(
  --[allocationId] char(4) primary key CONSTRAINT chk_C CHECK(allocationId LIKE 'A%'),
  [FarmerId] CHAR(4) references Farmers(FarmerId) primary key,
   [InvestorId] CHAR(4) references Investors(InvestorId) UNIQUE
)

--drop table admin
create table admin
(
[username] varchar(50) primary key,
[password] varchar(20)
)

create sequence Sequence_Investor
start with 10
increment by 1
go

create sequence Sequence_Farmer
start with 8
increment by 1
go

create sequence sequence_invest
start with 1
increment by 1
go

create sequence sequence_Purchase
start with 1
increment by 1
go

drop sequence Sequence_Investor

--go
	
create PROCEDURE usp_RegisterUser
(
	@UserName VARCHAR(15) ,
    @Name varchar(15),
	@UserPassword VARCHAR(15),
    @Role varchar(15),
	@Gender CHAR ,
	@Address VARCHAR(200),
	@PhoneNumber NUMERIC(10)

)
AS
BEGIN
	DECLARE @RoleId TINYINT
	BEGIN TRY
		IF (LEN(@UserName )<4 OR LEN(@UserName)>50 OR (@UserName IS NULL))
			RETURN -1
	   IF (LEN( @Name )<4 OR LEN( @Name)>50 OR (@Name IS NULL))
			RETURN -6
		IF (LEN(@UserPassword)<8 OR LEN(@UserPassword)>15 OR (@UserPassword IS NULL))
			RETURN -2
		IF (COUNT(@PhoneNumber)>10)
			RETURN -7
		IF (@Gender<>'F' AND @Gender<>'M' OR (@Gender Is NULL))
			RETURN -4	
		IF (@Address IS NULL)
			RETURN -5
		if(@Role='Farmers')
		 begin
		set  @RoleId=1
		select @RoleId
		 end
		else if(@Role='Investors')
		begin
		set @RoleId=2
		select @RoleId
		end
	    else
		begin
		set @RoleId=3
		select @RoleId
		end
INSERT INTO Users(UserName,[Name],UserPassword,RoleId,[Gender],[Address],PhoneNumber) VALUES 
(@UserName, @Name,@UserPassword,@RoleId, @Gender,  @Address,@PhoneNumber)
 RETURN 1
	END TRY
	BEGIN CATCH
		RETURN -99
	END CATCH
END
GO

begin
declare @returnvalue int
 EXEC @returnvalue=usp_RegisterUser 'aarti@gmail.com','John','Aman!10.',1,'M','Delhi',9955664321
 select @returnvalue as returnvalue
 end

select * from users
--GO

create PROCEDURE usp_AddFarmers
(
   	@UserName VARCHAR(15),
	@CropName varchar(20),
    @Land decimal 
	
)
AS
BEGIN
DECLARE @CropId CHAR(4) ,@TotalProductionCost  Numeric(10,3),@ProductionCost decimal ,
 @FarmerID char(4),@nextValue int = next value for Sequence_Farmer,@nextValue1 int = next value for sequence_invest
	BEGIN TRY
	
		IF (@CropName IS NULL)
			RETURN -2
		if NOT EXISTS (SELECT CropName from TypeofCrops WHERE CropName=@CropName)
		return -3
		IF ( @Land  IS NULL)
			RETURN -4

	  select @FarmerID = 'F' + convert(char(2),@nextValue)

	   SELECT  @CropId= CropId from TypeofCrops WHERE CropName=@CropName
	    SELECT  @ProductionCost=ProductionCost from TypeofCrops WHERE  CropName=@CropName
		SET @TotalProductionCost =@Land * @ProductionCost
	   --select top(1) @InvestorId=i.investorId from Investors i inner join  farmers f on i.CropId=f.CropId and @TotalProductionCost <=InvestmentAmount 
	 
		select @FarmerID,@UserName,@CropId,@Land,@TotalProductionCost
		INSERT INTO Farmers(FarmerId,UserName, CropId, Land, TotalProductionCost) VALUES 
		(@FarmerID,@UserName,@CropId,@Land,@TotalProductionCost)
		RETURN 1
	END TRY
	BEGIN CATCH
		select ERROR_MESSAGE() as ErrorMessage;
	END CATCH
END
GO
select * from users
select * from Kart
begin
declare @returnvalue int
 EXEC @returnvalue=usp_AddFarmers '5869001478','Paddy',25
 select @returnvalue as returnvalue
 end




select * from Farmers
create PROCEDURE usp_AddInvestors
( 
	@UserName VARCHAR(15),
	@CropName VARCHAR(20) ,
   @InvestmentAmount  Numeric(10,3),
	@ReturnType Varchar(20) 
)
AS
BEGIN
DECLARE @CropId CHAR(4) ,@FixedReturn Numeric ,@ProfitSharing Numeric ,@ProductMaterial Numeric,
		@Cost Numeric(10,3), @Land decimal ,@marketvalue decimal ,@Returns numeric(10,3) ,@InvestorID char(4),
		@nextValue int = next value for Sequence_Investor
	BEGIN TRY
		IF (@CropName IS NULL)
			RETURN -2
	   if( @InvestmentAmount IS NULL)
	      return -3
		if NOT EXISTS (SELECT CropName from TypeofCrops WHERE CropName=@CropName)
		return -4
		IF ( @ReturnType  IS NULL)
			RETURN -5
	
	select @InvestorID = 'I' + convert(char(2),@nextValue)
	
	SELECT  @CropId=CropId from TypeofCrops WHERE CropName=@CropName
	    if(@ReturnType ='Fixed Return')
		begin
		--SELECT @marketvalue= MarketValue, @CropId= CropId from TypeofCrops WHERE CropName=@CropName
		--select @FixedReturn=FixedReturn  from TypeofReturn WHERE @CropId= CropId
		--select @Land=Land,@Cost=TotalProductionCost from Farmers  where investorId IS NULL AND @InvestmentAmount >= TotalProductionCost
		--set @Returns=@cost+@FixedReturn*@cost/100
	  set @Returns=0
		end
		else if(@ReturnType ='Profit sharing')
			begin
		--SELECT @marketvalue= MarketValue, @CropId= CropId from TypeofCrops WHERE CropName=@CropName
		--select @FixedReturn=FixedReturn  from TypeofReturn WHERE @CropId= CropId
		--select @Land=Land,@Cost=TotalProductionCost from Farmers  where investorId IS NULL AND @InvestmentAmount >= TotalProductionCost
		--set @Returns=@Cost+@ProfitSharing * (@Marketvalue*@land-@Cost)/100
		 set @Returns=0
		end
		else
		begin
		--SELECT @marketvalue= MarketValue, @CropId= CropId from TypeofCrops WHERE CropName=@CropName
		--select @FixedReturn=FixedReturn  from TypeofReturn WHERE @CropId= CropId
		--select @Land=Land,@Cost=TotalProductionCost from Farmers  where investorId IS NULL AND @InvestmentAmount >= TotalProductionCost
		--set @Returns= (@ProductMaterial*@Marketvalue/100 )*@land
		set @Returns=0
		end
		select @InvestorID,@UserName,@CropId,@InvestmentAmount,@ReturnType,@Returns
		INSERT INTO Investors(InvestorId,UserName,CropId,InvestmentAmount,ReturnType,[Returns]) VALUES 
		(@InvestorID,@UserName,@CropId,@InvestmentAmount,@ReturnType,@Returns)
		RETURN 1
	END TRY
	BEGIN CATCH
		RETURN -99
	END CATCH
END
GO
select * from Investors
select * from users
exec usp_AddInvestors 'aba@gmail.com','Paddy',4000,'Fixed Return'

begin
declare @returnvalue int
 exec @returnvalue= usp_AddInvestors 'aba@gmail.com','Paddy',4000,'Fixed Return'
 select @returnvalue as returnvalue
 end

select * from TypeofCrops
select * from TypeofReturn
select * from allocate
select * from Users
select * from farmers
select * from investors
delete from farmers where TotalProductionCost=9000

--CREATE FUNCTION ufn_ValidateUserCredentials
--(
--	@UserName VARCHAR(15) ,
--	@UserPassword VARCHAR(15)
--)
--RETURNS INT
--AS
--BEGIN
--	DECLARE @RoleId INT
--	SELECT  @RoleId=RoleId FROM Users WHERE UserName=@UserName  AND UserPassword=@UserPassword
--	return @RoleId
--END
--GO



--Insertion script for buyer 
INSERT [dbo]. [Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B1  ', 'C1  ', 20, CAST(300.000 AS Numeric(10, 3)))
INSERT [dbo]. [Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B2  ', 'C2  ', 52, CAST(560.000 AS Numeric(10, 3)))
INSERT [dbo]. [Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B3  ', 'C3  ', 30, CAST(450.000 AS Numeric(10, 3)))
INSERT [dbo].[Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B4  ', 'C4  ', 40, CAST(160.000 AS Numeric(10, 3)))
INSERT [dbo]. [Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B5  ', 'C5  ', 15, CAST(600.000 AS Numeric(10, 3)))
INSERT [dbo]. [Buyers] ([BuyerId], [CropId], [Quantity], [Purchasing amount]) VALUES ('B6  ', 'C6  ', 35, CAST(740.000 AS Numeric(10, 3)))

select * from users
--Insertion script for users
INSERT [dbo].[Users] ([UserName], [Name], [UserPassword], [RoleId], [Gender], [Address], [PhoneNumber]) VALUES ('5@21.069','Alice', 'SGTY@452', 2, 'F', 'Andrew Circuit', CAST(5821400369 AS Numeric(10, 0)))
INSERT [dbo].[Users] ([UserName], [Name], [UserPassword], [RoleId], [Gender], [Address], [PhoneNumber]) VALUES (N'5@69.878', N'Nicole', N'FRTY@559', 1, 'M', N'Circle Road', CAST(5869001478 AS Numeric(10, 0)))
INSERT [dbo].[Users] ([UserName], [Name], [UserPassword], [RoleId], [Gender], [Address], [PhoneNumber]) VALUES (N'7@85.236', N'Harry', N'HARR@895',  3, 'M', N'Inner Road', CAST(7856230236 AS Numeric(10, 0)))
INSERT [dbo].[Users] ([UserName], [Name], [UserPassword], [RoleId], [Gender], [Address], [PhoneNumber]) VALUES (N'8@54.358', N'Franken', N'XCVF@134', 3, 'M', N'Fauntleroy Circus', CAST(8541023358 AS Numeric(10, 0)))
INSERT [dbo].[Users] ([UserName], [Name], [UserPassword], [RoleId], [Gender], [Address], [PhoneNumber]) VALUES (N'9@68.401', N'August', N'OOIU@013', 2, 'F', N'Sparky Ridge Road', CAST(9685234001 AS Numeric(10, 0)))
select * from TypeofReturn
select * from TypeofCrops
--Insertion script fro TypeofReturn
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C1  ', CAST(500 AS Numeric(18, 0)), CAST(200 AS Numeric(18, 0)), CAST(300 AS Numeric(18, 0)))
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C2  ', CAST(600 AS Numeric(18, 0)), CAST(400 AS Numeric(18, 0)), CAST(200 AS Numeric(18, 0)))
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C3  ', CAST(700 AS Numeric(18, 0)), CAST(300 AS Numeric(18, 0)), CAST(400 AS Numeric(18, 0)))
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C4  ', CAST(400 AS Numeric(18, 0)), CAST(200 AS Numeric(18, 0)), CAST(200 AS Numeric(18, 0)))
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C5  ', CAST(300 AS Numeric(18, 0)), CAST(100 AS Numeric(18, 0)), CAST(200 AS Numeric(18, 0)))
INSERT [dbo].[TypeofReturn] ([CropId], [FixedReturn], [ProfitSharing], [ProductMaterial]) VALUES (N'C6  ', CAST(800 AS Numeric(18, 0)), CAST(100 AS Numeric(18, 0)), CAST(700 AS Numeric(18, 0)))

--insert into Users([UserName],[Name] ,[UserPassword],[RoleId],[Gender],[Address],[PhoneNumber],[Image]) SELECT 'Baby@gmail.com','baby','Baby@123',1,'F','Delhi','9934566278',bulkcolumn from OPENROWSET(BULK 'X:\download1.JPG',SINGLE_BLOB) AS [Image]

--Insertion script for typeofcrops
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C1  ', N'Paddy', CAST(3 AS Decimal(18, 0)), CAST(200 AS Decimal(18, 0)), CAST(250 AS Decimal(18, 0)))
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C2  ', N'Wheat', CAST(6 AS Decimal(18, 0)), CAST(300 AS Decimal(18, 0)), CAST(350 AS Decimal(18, 0)))
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C3  ', N'Jowar', CAST(9 AS Decimal(18, 0)), CAST(290 AS Decimal(18, 0)), CAST(300 AS Decimal(18, 0)))
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C4  ', N'Bajra', CAST(12 AS Decimal(18, 0)), CAST(100 AS Decimal(18, 0)), CAST(150 AS Decimal(18, 0)))
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C5  ', N'Mushroom', CAST(3 AS Decimal(18, 0)), CAST(400 AS Decimal(18, 0)), CAST(470 AS Decimal(18, 0)))
INSERT [dbo].[TypeofCrops] ([CropId], [CropName], [TimePeriod], [ProductionCost], [MarketValue]) VALUES (N'C6  ', N'Grains', CAST(6 AS Decimal(18, 0)), CAST(321 AS Decimal(18, 0)), CAST(330 AS Decimal(18, 0)))
select * from TypeofCrops
select * from Users
select * from Investors
insert into investors values('I2','5821400369','C4',1000,'Profit Sharing',0)
insert into Farmers values('F10',N'9@68.401','C2',700,5000)
select * from farmers
delete from allocate where FarmerId='F8'
select * from Investors
select * from  allocate
insert into admin values('admin','admin123')
--Insertion script for investors
INSERT [dbo].[Investors] ([InvestorId],[UserName], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I1' ,'5821400369', N'C1', CAST(65789.980 AS Numeric(10, 3)), N'Fixed Return', CAST(67000.000 AS Numeric(10, 3)))
INSERT [dbo].[Investors] ([InvestorId], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I2  ', N'C2  ', CAST(892300.967 AS Numeric(10, 3)), N'Profit Sharing', CAST(900000.000 AS Numeric(10, 3)))
INSERT [dbo].[Investors] ([InvestorId], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I3  ', N'C3  ', CAST(58965.324 AS Numeric(10, 3)), N'Product Material', CAST(59000.000 AS Numeric(10, 3)))
INSERT [dbo].[Investors] ([InvestorId], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I4  ', N'C4  ', CAST(45900.768 AS Numeric(10, 3)), N'Fixed Return', CAST(47000.000 AS Numeric(10, 3)))
INSERT [dbo].[Investors] ([InvestorId], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I5  ', N'C5  ', CAST(3200000.009 AS Numeric(10, 3)), N'Profit Sharing', CAST(3300000.000 AS Numeric(10, 3)))
INSERT [dbo].[Investors] ([InvestorId], [CropId], [InvestmentAmount], [ReturnType], [Returns]) VALUES (N'I6  ', N'C6  ', CAST(48900.765 AS Numeric(10, 3)), N'Product Material', CAST(50000.000 AS Numeric(10, 3)))




--Insertion scripts for farmers
INSERT [dbo].[Farmers] ([FarmerId], [UserName],[CropId], [Land], [TotalProductionCost]) VALUES (N'F1  ', N'C1  ', CAST(50 AS Decimal(18, 0)), N'I1  ', CAST(10000.000 AS Numeric(10, 3)))
INSERT [dbo].[Farmers] ([FarmerId],[UserName], [CropId], [Land], [TotalProductionCost]) VALUES (N'F2  ', N'C2  ', CAST(30 AS Decimal(18, 0)), N'I2  ', CAST(9000.000 AS Numeric(10, 3)))
INSERT [dbo].[Farmers] ([FarmerId],[UserName], [CropId], [Land], [TotalProductionCost]) VALUES (N'F3  ', N'C3  ', CAST(25 AS Decimal(18, 0)), N'I3  ', CAST(7250.000 AS Numeric(10, 3)))
INSERT [dbo].[Farmers] ([FarmerId],[UserName], [CropId], [Land], [TotalProductionCost]) VALUES (N'F4  ', N'C4  ', CAST(15 AS Decimal(18, 0)), N'I4  ', CAST(1500.000 AS Numeric(10, 3)))
INSERT [dbo].[Farmers] ([FarmerId],[UserName], [CropId], [Land], [TotalProductionCost]) VALUES (N'F5  ', N'C5  ', CAST(45 AS Decimal(18, 0)), N'I5  ', CAST(18000.000 AS Numeric(10, 3)))
INSERT [dbo].[Farmers] ([FarmerId],[UserName], [CropId], [Land],[TotalProductionCost]) VALUES (N'F7  ', N'C6  ', CAST(13 AS Decimal(18, 0)), null , CAST(2000.000 AS Numeric(10, 3)))



select * from TypeofCrops
select * from Investors
select * from Farmers
select * from users
select * from allocate
select * from admin
--Scaffold-DbContext -Connection "Data Source =(localdb)\mssqllocaldb;Initial Catalog=AgroFarmDB;Integrated Security=true" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models

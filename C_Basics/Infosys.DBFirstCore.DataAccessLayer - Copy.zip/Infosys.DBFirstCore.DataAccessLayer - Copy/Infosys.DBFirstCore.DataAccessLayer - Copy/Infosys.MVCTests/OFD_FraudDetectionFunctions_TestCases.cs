﻿using Infosys.DBFirstCore.DataAccessLayer;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Infosys.MVCTests
{
    [TestClass]
    public class OFD_FraudDetectionFunctions_TestCases
    {
        OFD_Repository ofd_Repository = new OFD_Repository();

        //If account number does not match
        [TestMethod]
        public void CheckAccountNumber_Negative()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckAmountDeviation("007063332200001", 3000);
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }

        //No. 1
        //Amount Varry Function Test
        //If amount and account number is true
        [TestMethod]
        public void CheckAmount_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckAmountDeviation("007066100000007", 0);
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);
        }

        //If amount does not varry from previous transactions
        [TestMethod]
        public void CheckAmount_Negative()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckAmountDeviation("007066100000001", 1500);
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }

        //No. 2
        //Checking Location of payment and comparing it with previous locations

        //If current payment Location matches with previous locations
        [TestMethod]
        public void CheckLocation_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckLocation("007066100000009", "India");
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);
        }

        //If current payment Location does not match with previous locations
        [TestMethod]
        public void CheckLocation_Negative()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckLocation("007066100000001", "USA");
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }

        //No. 3
        //Checking IP Address of payment system and comparing with previous Adresses
        //If Current IP Address matches with previous IP Addresses
        [TestMethod]
        public void CheckIpAddress_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckIp("007066100000009", "192.168.0.1");
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);
        }

        //If current IP Address does not match with previous Addresses
        [TestMethod]
        public void CheckIpAddress_Negative()
        {
            int expected = 1;
            ofd_Repository.OFD_CheckIp("007066100000001", "191.167.0.2");
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }


        //No. 4
        //Checking CVV , Pin and comparing amount with balance of bank account 
        //If CVV,pin and amount matches with bank balance
        [TestMethod]
        public void CheckOut_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_Checkout(1146665296881890, 21, 137, 123);
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);
        }

        //If Amount does not match with bank balance
        [TestMethod]
        public void CheckOut_Negative1()
        {
            int expected = 1;
            ofd_Repository.OFD_Checkout(1146665296881890, 2221, 137, 123);
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }
        //If CVV does not match
        [TestMethod]
        public void CheckOut_Negative2()
        {
            int expected = 1;
            ofd_Repository.OFD_Checkout(1146665296881890, 2221, 117, 123);
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }
        //If PIN does not match
        [TestMethod]
        public void CheckOut_Negative3()
        {
            int expected = 1;
            ofd_Repository.OFD_Checkout(1146665296881890, 2221, 137, 223);
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);
        }

        //No5 Checking activation of user account
        //If account is not locked
        [TestMethod]
        public void ActivationCheck_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_ActivationCheck("007066100000001");
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);

        }

        //If Account is locked
        [TestMethod]
        public void ActivationCheck_Negative()
        {
            int expected = 1;
            ofd_Repository.OFD_ActivationCheck("007066100000007");
            int real = ofd_Repository.Test;
            Assert.AreNotEqual(expected, real);

        }

        //No6 Checking Security pin
        //If pin is available
        [TestMethod]
        public void SecurityPin_Positive()
        {
            int expected = 1;
            ofd_Repository.OFD_SecurityPin("akash21@gmail.com");
            int real = ofd_Repository.Test;
            Assert.AreEqual(expected, real);

        }

      
    }
}

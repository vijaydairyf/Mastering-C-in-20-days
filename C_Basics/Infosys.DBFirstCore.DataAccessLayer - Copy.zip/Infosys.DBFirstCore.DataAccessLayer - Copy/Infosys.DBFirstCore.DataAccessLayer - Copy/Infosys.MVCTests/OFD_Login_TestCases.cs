﻿using Infosys.DBFirstCore.DataAccessLayer;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Infosys.MVCTests
{
    [TestClass]
    public class OFD_Login_TestCases
    {
        OFD_Repository telerRepository = new OFD_Repository();
        //Admin Login Success
        [TestMethod]
        public void ValidateCredentials_Positive1() {
            int expected = 1;
            telerRepository.OFD_ValidateCredentials("akash@gupta.com", "jack");
            int actual = telerRepository.Test;
            Assert.AreEqual(expected,actual);
        }
   

        //User Login Success
        [TestMethod]
        public void ValidateCredentials_Positive2()
        {
            int expected = 1;
            telerRepository.OFD_ValidateCredentials("Albert@gmail.com", "LILAS@1234");
            int real = telerRepository.Test;
            Assert.AreEqual(expected,real);
        }

        //Invalid User Id
        [TestMethod]
        public void ValidateCredentials_Negative1()
       {
            int expected = -99;
            telerRepository.OFD_ValidateCredentials("ankit@nagar.com", "jack");
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }

        //Invalid User Password
        [TestMethod]
        public void ValidateCredentials_Negative2()
        {
            int expected = -99;
            telerRepository.OFD_ValidateCredentials("akash2@gupta.com", "jjack");
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }
        //Invalid Admin Id
        [TestMethod]
        public void ValidateCredentials_Negative3()
        {
            int expected = -99;
             telerRepository.OFD_ValidateCredentials("akash@nagar.com", "jack");
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }

        //Invalid User Password
        [TestMethod]
        public void ValidateCredentials_Negative4()
        {
            int expected = -99;
             telerRepository.OFD_ValidateCredentials("akash2@gupta.com", "jjack");
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }

    }
}

﻿using Infosys.DBFirstCore.DataAccessLayer;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Infosys.MVCTests
{
    [TestClass]
    public class OFD_Registration_TestCases
    {
        OFD_Repository telerRepository = new OFD_Repository();
        //For all the users roleId is by default 2

        //Successfull Registration
        //[TestMethod]
        //public void Users_Positive1()
        //{
        //    Users user = new Users();
        //    user.EmailId = "anktt@gmail.com";
        //    user.UserPassword = "12345678";
        //    user.Gender = "M";
        //    user.DateOfBirth = new DateTime(1997 - 10 - 04);
        //    user.Address = "Kota";
        //    user.Location = "india";
        //    user.SecurityAnswer = "Cricket";
        //    user.SecurityPin = 545555;
        //    user.ContactNo = 8290854443;
        //    user.Zipcode = 326022;
        //    user.RoleId = 2;
        //    int expected = 1;
        //    telerRepository.Users(user);
        //    int real = telerRepository.Test;
        //    Assert.AreEqual(expected, real);
        //}
        
        
        //In gender there should be only F or M
        [TestMethod]
        public void Users_Negative1()
        {
            Users user = new Users();
            user.EmailId = "ankit@gmail.com";
            user.UserPassword = "12345678";
            user.Gender = "Male";
            user.DateOfBirth = new DateTime(1997 - 10 - 04);
            user.Address = "Kota";
            user.Location = "india";
            user.SecurityAnswer = "Cricket";
            user.SecurityPin = 545555;
            user.ContactNo = 8290854443;
            user.Zipcode = 326022;
            user.RoleId = 2;
            int expected = -99;
            telerRepository.OFD_Users(user);
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }
        [TestMethod]
        public void Users_Negative2()
        {
            Users user = new Users();
            user.EmailId = "ankit@gmail.com";
            user.UserPassword = "12345678";
            user.Gender = "Female";
            user.DateOfBirth = new DateTime(1997 - 10 - 04);
            user.Address = "Kota";
            user.Location = "india";
            user.SecurityAnswer = "Cricket";
            user.SecurityPin = 545555;
            user.ContactNo = 8290854443;
            user.Zipcode = 326022;
            user.RoleId = 2;
            int expected = -99;
            telerRepository.OFD_Users(user);
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }
        //Location must be less than or equal to 10 char
        [TestMethod]
        public void Users_Negative3()
        {
            Users user = new Users();
            user.EmailId = "nitika@gmail.com";
            user.UserPassword = "12345678";
            user.Gender = "m";
            user.DateOfBirth = new DateTime(1997 - 10 - 04);
            user.Address = "Kota";
            user.Location = "kotarajasthanindia";
            user.SecurityAnswer = "Cricket";
            user.SecurityPin = 545555;
            user.ContactNo = 8293354443;
            user.Zipcode = 326021;
            user.RoleId = 2;
            int expected = -99;
            telerRepository.OFD_Users(user);
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }
        //Security answer must be less than or equal to 10 char
        [TestMethod]
        public void Users_Negative4()
        {
            Users user = new Users();
            user.EmailId = "ankit@gmail.com";
            user.UserPassword = "12345678";
            user.Gender = "Female";
            user.DateOfBirth = new DateTime(1997 - 10 - 04);
            user.Address = "Kota";
            user.Location = "india";
            user.SecurityAnswer = "Cricketisatimepassgame";
            user.SecurityPin = 545555;
            user.ContactNo = 8290854443;
            user.Zipcode = 326022;
            user.RoleId = 2;
            int expected = -99;
            telerRepository.OFD_Users(user);
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }
        //ZipCode must be equal to 6 number
        [TestMethod]
        public void Users_Negative5()
        {
            Users user = new Users();
            user.EmailId = "vishal@gmail.com";
            user.UserPassword = "2222345678";
            user.Gender = "Female";
            user.DateOfBirth = new DateTime(1997 - 10 - 04);
            user.Address = "Kota";
            user.Location = "india";
            user.SecurityAnswer = "Cricketisatimepassgame";
            user.SecurityPin = 54552355;
            user.ContactNo = 829435443;
            user.Zipcode = 326022;
            user.RoleId = 2;
            int expected = -99;
            telerRepository.OFD_Users(user);
            int real = telerRepository.Test;
            Assert.AreEqual(expected, real);
        }


    }
}


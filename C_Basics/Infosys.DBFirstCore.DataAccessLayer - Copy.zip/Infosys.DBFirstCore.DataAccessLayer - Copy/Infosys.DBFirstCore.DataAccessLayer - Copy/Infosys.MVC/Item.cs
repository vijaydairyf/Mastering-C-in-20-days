﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.MVC.Models;

namespace Infosys.MVC
{   
    [Serializable]
    public class Item
    {
        public Products Product { get; set; }

        public int Quantity { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.DBFirstCore.DataAccessLayer.Models;

namespace Infosys.MVC
{
    public class DBFirstCoreMapper:Profile
    {
        public DBFirstCoreMapper()
        {
            CreateMap<Users, Models.Users>();
            CreateMap<Models.Users, Users>();
            CreateMap<Models.Products, Products>();
            CreateMap<Products, Models.Products>();
            CreateMap<Models.Transaction, Transaction>();
            CreateMap<Transaction, Models.Transaction>();
        }
    }
}

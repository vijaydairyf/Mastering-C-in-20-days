﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.MVC.Models
{
    public class Users
    {
        public string EmailId { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public string Location { get; set; }
        public string SecurityAnswer { get; set; }
        public int SecurityPin { get; set; }
        public long ContactNo { get; set; }
        public int Zipcode { get; set; }
    }
}

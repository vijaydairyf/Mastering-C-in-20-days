﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.MVC.Models
{
    public class Transaction
    {
        public long TransactionId { get; set; }
        public string AccountNumber { get; set; }
        public decimal Amount { get; set; }
        public DateTime TransactionDateTime { get; set; }
        public bool Type { get; set; }
        public string Mode { get; set; }
        public string Remarks { get; set; }
        public string Info { get; set; }
        public string CreatedBy { get; set; }
        public string Location { get; set; }
        public int? Limit { get; set; }
        public string IpAddress { get; set; }
        public int Zipcode { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;




using Infosys.MVC.Models;
using Infosys.MVC.Helper;

namespace Infosys.MVC.Controllers
{
    public class AddToCartController : Controller
    {
        //DataContext db = new DataContext();


        //public ActionResult Add(Products mo)
        //{
        //    HttpContext.Session.

        //    if (Session["cart"] == null)
        //    {
        //        List<Products> li = new List<Products>();

        //        li.Add(mo);
        //        Session["cart"] = li;
        //        ViewBag.cart = li.Count();


        //        Session["count"] = 1;


        //    }
        //    else
        //    {
        //        List<Products> li = (List<Products>)Session["cart"];
        //        li.Add(mo);
        //        Session["cart"] = li;
        //        ViewBag.cart = li.Count();
        //        Session["count"] = Convert.ToInt32(Session["count"]) + 1;

        //    }
        //    return RedirectToAction("Index", "Home");


        //}


















        // GET: AddToCart
       
        public ActionResult Index()
        {
            TempData["email"] = HttpContext.Session.GetString("email");
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            if (ViewBag.cart != null)
            {
                ViewBag.total = cart.Sum(i => i.Product.Price * i.Quantity);
                ViewBag.count = cart.Sum(j => j.Quantity);
                TempData["count"] = ViewBag.count;
                TempData["total"] = ViewBag.total;
                String count = Convert.ToString(TempData["count"]);
                String total = Convert.ToString(TempData["total"]);
                HttpContext.Session.SetString("count",count);
                HttpContext.Session.SetString("total", total);
               
            }
            
            return View();
        }

        public ActionResult Buy(Products p)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            if (SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart") == null)
            {
                List<Item> cart = new List<Item>();
                decimal a = p.Price;
                //var cart = new List<Item>();
                cart.Add(new Item() { Product = p, Quantity = 1 });
                SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);
                var cart2 = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            }
            else {
                List<Item> cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
                int index = Exists(cart, p.ProductId);
                if (index == -1)
                {
                    cart.Add(new Item() { Product = p, Quantity = 1 });
                    
                }
                else
                {
                    cart[index].Quantity++;
                }
                SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);
            }
           
            return RedirectToAction("Index");
        }




        public ActionResult DeleteProduct(Products i)
        {
            
            List<Item> cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");

            string y = i.ProductId;
            int index = Exists(cart, y);


            if (cart[index].Quantity == 1)
            {
                cart.RemoveAt(index);

            }
            else
            {
                cart[index].Quantity--;
            }
            SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);

        
           
            return RedirectToAction("Index");

        }








        private int Exists(List<Item> cart, string id)
        {
            for (int i = 0; i < cart.Count; i++)
            {
                if((cart[i].Product.ProductId) == id)
                {
                    return i;
                }
            }
            return -1;
        }


        // GET: AddToCart/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: AddToCart/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AddToCart/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AddToCart/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AddToCart/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AddToCart/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AddToCart/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.DBFirstCore.DataAccessLayer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http.Features;
using Infosys.MVC.Helper;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using ClassLibrary1;

using System.Net.Mail;
using static System.Net.WebRequestMethods;

namespace Infosys.MVC.Controllers
{
    public class CheckOutController : Controller
    {
        private IHttpContextAccessor _accessor;


        private readonly IMapper _mapper;
        OFD_Repository tel;
        public CheckOutController(IMapper mapper, OFD_Repository telerr,IHttpContextAccessor accessor)
        {
            
            _accessor = accessor;
            _mapper = mapper;
            tel = telerr;
        }


        PurchaseDetails pd = new PurchaseDetails();
        Transaction transaction = new Transaction();
        decimal cardNo;
        int cvv;
        int amt;



        // GET: CheckOut
        public ActionResult Payment()
        {
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["total"] = HttpContext.Session.GetString("total");

            Class1 mail = new Class1();

            Random random2 = new Random();
            int j = random2.Next(1000, 9999);
            TempData["verify"] = j.ToString();

            HttpContext.Session.SetString("verify", (TempData["verify"]).ToString());
            TempData["verify"] = HttpContext.Session.GetString("verify");






            Random random = new Random();
            int i = random.Next(1000, 9999);
            TempData["code"] = i.ToString();

            HttpContext.Session.SetString("code", (TempData["code"]).ToString());
            TempData["code"] = HttpContext.Session.GetString("code");


            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");



            //mail.sendEMailThroughOUTLOOK(TempData["email"].ToString(), TempData["verify"].ToString());




            return View();
        }

        // GET: CheckOut/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CheckOut/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CheckOut/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Payment));
            }
            catch
            {
                return View();
            }
        }

        // GET: CheckOut/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CheckOut/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Payment));
            }
            catch
            {
                return View();
            }
        }

        // GET: CheckOut/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: CheckOut/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Payment));
            }
            catch
            {
                return View();
            }
        }


        public ActionResult Security()
        {
            //ViewBag.AccountNumber = ViewBag.AccountNumber;
            //ViewBag.Amount = ViewBag.Amount;
            //ViewBag.IpAddress = "192.168.0.1";
            //ViewBag.Location = ViewBag.Location;
            //ViewBag.Limit = 5000;
            //ViewBag.Info = ViewBag.Info;
            //ViewBag.Remarks = ViewBag.Remarks;
            //ViewBag.Mode = ViewBag.Mode;
            //ViewBag.Type = true;
            //ViewBag.Zipcode = ViewBag.Zipcode;
            //ViewBag.CreatedBy = ViewBag.CreatedBy;
            //ViewBag.TransactionDateTime = ViewBag.TransactionDateTime;
            return View();
        }



        public ActionResult CheckAnswer(IFormCollection frm)
        {
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["total"] = HttpContext.Session.GetString("total");
            bool status = false;
            string ans1 = tel.OFD_SecurityAnswer(HttpContext.Session.GetString("email"));
            int ans2 = tel.OFD_SecurityPin(HttpContext.Session.GetString("email"));






            transaction.AccountNumber = TempData["a1"].ToString();
            transaction.Amount =Convert.ToDecimal (TempData["a2"]);
            transaction.IpAddress = TempData["a3"].ToString();
            transaction.Location = TempData["a4"].ToString();
            transaction.Limit = Convert.ToInt32( TempData["a5"]);
            transaction.Info = TempData["a6"].ToString();
            transaction.Remarks = TempData["a7"].ToString();
            transaction.Mode = TempData["a8"].ToString();
            transaction.Type =Convert.ToBoolean( TempData["a9"].ToString());
            transaction.Zipcode =Convert.ToInt32 ( TempData["a10"]);
            transaction.CreatedBy = TempData["a11"].ToString();
            transaction.TransactionDateTime = Convert.ToDateTime(TempData["a12"]);





            if (frm["answer1"] == ans1 && frm["answer2"]==Convert.ToString(ans2))
            {
                cardNo = Convert.ToDecimal(HttpContext.Session.GetString("cardNo"));
                cvv = Convert.ToInt32(HttpContext.Session.GetString("cvv"));
                amt = Convert.ToInt32(HttpContext.Session.GetString("amt"));
                status = tel.OFD_Checkout(cardNo, amt, cvv, 123);
                if (status == true)
                {
                    var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
                    foreach (var item in cart)
                    {
                        pd.Product = item.Product.ProductId;
                        pd.QuantityPurchased = (short)item.Quantity;
                        status = tel.OFD_PurchaseProduct(pd);
                    }
                    if (status == true)
                    {
                        tel.OFD_AddTransaction(transaction);
                        HttpContext.Session.Remove("cart");
                        HttpContext.Session.Remove("count");
                        HttpContext.Session.Remove("code");
                        HttpContext.Session.Remove("verify");
                        HttpContext.Session.Remove("total");
                        //return RedirectToAction("Customer", "Home");
                        return View("Success");
                    }

                    else
                    {
                        return View("Error");
                    }
                }
                else
                {
                    return View("BalanceError");
                }
            }
            else
                return View("Error");
        }





        public IActionResult CheckDetail(IFormCollection frm)
        {



            Class1 mail = new Class1();


            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["total"]= HttpContext.Session.GetString("count");
            if (TempData["total"] == null) {
                return View("Success");
            }

            bool status = false;
            string capche = frm["code"];
            string otp = frm["verify"];
            cardNo = Convert.ToDecimal(frm["card"]);
            cvv = Convert.ToInt32(frm["cvv"]);
            string acountNo = frm["acn"];
            string name = frm["fname"] + frm["lname"];
            int zipCode = Convert.ToInt32(frm["zipCode"]);
            string lcn = frm["country"];
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            ViewBag.total = cart.Sum(i => i.Product.Price * i.Quantity);
            TempData["total"] = ViewBag.total;
            amt = Convert.ToInt32(TempData["total"]);
            HttpContext.Session.SetString("amt", Convert.ToString(amt));
            HttpContext.Session.SetString("cvv", frm["cvv"]);
            HttpContext.Session.SetString("cardNo", frm["card"]);
            pd.EmailId = HttpContext.Session.GetString("email");
            DateTime time2 = new DateTime();
            time2 = DateTime.Now;
            pd.DateOfPurchase = time2;
            if (capche != HttpContext.Session.GetString("code"))
            {
                TempData["Message"] = "wrongcapthe";
                return RedirectToAction("Payment", "CheckOut");
            }
            //if (otp != HttpContext.Session.GetString("verify"))
            //{
            //    return RedirectToAction("Payment", "CheckOut");
            //}
            if (tel.OFD_ActivationCheck(acountNo) == false)
            {
                mail.sendSecurityEMailThroughOUTLOOK((TempData["email"]).ToString());
                return View("Error");
                
            }
            status = tel.OFD_CheckLocation(acountNo, lcn);
                if(status==false)
                status = tel.OFD_TransTime(acountNo, zipCode);
                if(status==false)
                status = tel.OFD_CheckAmountDeviation(acountNo, amt);

            TempData["a1"] = acountNo;
            TempData["a2"] = amt;
            TempData["a3"] = "192.168.0.1";
            TempData["a4"] = lcn;
            TempData["a5"] = 5000;
            TempData["a6"] = name;
            TempData["a7"] = "Account debited with Rs" + amt;
            TempData["a8"] = "Teller";
            TempData["a9"] = true;
            TempData["a10"] = zipCode;
            TempData["a11"] = (TempData["email"]).ToString();
            TempData["a12"] = time2;

            transaction.AccountNumber = acountNo;
            transaction.Amount = amt;
            transaction.IpAddress = "192.168.0.1";
            transaction.Location = lcn;
            transaction.Limit = 5000;
            transaction.Info = name;
            transaction.Remarks = "Account debited with Rs" + amt;
            transaction.Mode = "Teller";
            transaction.Type = true;
            transaction.Zipcode = zipCode;
            transaction.CreatedBy = (TempData["email"]).ToString();
            transaction.TransactionDateTime = time2;

            if (status == true)
            {
                return RedirectToAction("Security");
            }

            status = tel.OFD_Checkout(cardNo, amt, cvv, 123);
            if (status == true)
            {
                foreach (var item in cart)
                {
                    pd.Product = item.Product.ProductId;
                    pd.QuantityPurchased = (short)item.Quantity;
                    status = tel.OFD_PurchaseProduct(pd);
                }
                tel.OFD_AddTransaction(transaction);
                HttpContext.Session.Remove("cart");
                HttpContext.Session.Remove("count");
                HttpContext.Session.Remove("code");
                HttpContext.Session.Remove("verify");
                HttpContext.Session.Remove("total");
                //return View("Sucess");
                return View("Success");
            }
            else
            {   

                return View("BalanceError");
            }



            
        }

        


    }
}
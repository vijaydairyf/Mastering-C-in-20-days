﻿using System;
using System.Collections.Generic;

namespace Infosys.DBFirstCore.DataAccessLayer.Models
{
    public partial class CustomerLogin
    {
        public int CustomerLoginId { get; set; }
        public string LoginName { get; set; }
        public byte[] Password { get; set; }
        public long CustomerId { get; set; }
        public int IsLocked { get; set; }
        public DateTime? ModifiedTimestamp { get; set; }

        public virtual Customer Customer { get; set; }
    }
}

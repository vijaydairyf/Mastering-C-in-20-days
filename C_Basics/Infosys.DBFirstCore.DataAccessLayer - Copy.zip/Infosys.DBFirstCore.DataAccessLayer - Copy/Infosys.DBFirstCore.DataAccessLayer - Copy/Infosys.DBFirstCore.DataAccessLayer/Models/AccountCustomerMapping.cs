﻿using System;
using System.Collections.Generic;

namespace Infosys.DBFirstCore.DataAccessLayer.Models
{
    public partial class AccountCustomerMapping
    {
        public int AccountCustomerMappingId { get; set; }
        public string AccountNumber { get; set; }
        public long CustomerId { get; set; }
        public bool? IsActive { get; set; }

        public virtual Account AccountNumberNavigation { get; set; }
        public virtual Customer Customer { get; set; }
        public virtual DebitCard DebitCard { get; set; }
    }
}

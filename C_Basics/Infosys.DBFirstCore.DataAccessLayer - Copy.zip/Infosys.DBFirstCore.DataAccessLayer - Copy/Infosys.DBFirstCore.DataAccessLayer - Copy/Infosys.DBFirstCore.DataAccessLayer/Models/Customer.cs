﻿using System;
using System.Collections.Generic;

namespace Infosys.DBFirstCore.DataAccessLayer.Models
{
    public partial class Customer
    {
        public Customer()
        {
            AccountCustomerMapping = new HashSet<AccountCustomerMapping>();
            CustomerLogin = new HashSet<CustomerLogin>();
        }

        public long CustomerId { get; set; }
        public string EmailId { get; set; }
        public string Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public DateTime CreatedTimeStamp { get; set; }
        public byte CreatedBy { get; set; }
        public DateTime? ModifiedTimeStamp { get; set; }
        public byte? ModifiedBy { get; set; }

        public virtual Teller CreatedByNavigation { get; set; }
        public virtual Teller ModifiedByNavigation { get; set; }
        public virtual ICollection<AccountCustomerMapping> AccountCustomerMapping { get; set; }
        public virtual ICollection<CustomerLogin> CustomerLogin { get; set; }
    }
}

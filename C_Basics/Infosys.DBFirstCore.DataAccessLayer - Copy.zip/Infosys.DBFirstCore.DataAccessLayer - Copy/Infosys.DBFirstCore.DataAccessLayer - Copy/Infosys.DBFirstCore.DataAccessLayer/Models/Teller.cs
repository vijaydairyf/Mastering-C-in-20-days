﻿using System;
using System.Collections.Generic;

namespace Infosys.DBFirstCore.DataAccessLayer.Models
{
    public partial class Teller
    {
        public Teller()
        {
            AccountCreatedByNavigation = new HashSet<Account>();
            AccountModifiedByNavigation = new HashSet<Account>();
            CustomerCreatedByNavigation = new HashSet<Customer>();
            CustomerModifiedByNavigation = new HashSet<Customer>();
            DebitCard = new HashSet<DebitCard>();
        }

        public byte TellerId { get; set; }
        public string LoginName { get; set; }
        public byte[] Password { get; set; }

        public virtual ICollection<Account> AccountCreatedByNavigation { get; set; }
        public virtual ICollection<Account> AccountModifiedByNavigation { get; set; }
        public virtual ICollection<Customer> CustomerCreatedByNavigation { get; set; }
        public virtual ICollection<Customer> CustomerModifiedByNavigation { get; set; }
        public virtual ICollection<DebitCard> DebitCard { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Infosys.DBFirstCore.DataAccessLayer.Models
{
    public partial class Account
    {
        public Account()
        {
            Transaction = new HashSet<Transaction>();
        }

        public int AccountId { get; set; }
        public string AccountNumber { get; set; }
        public byte BranchId { get; set; }
        public decimal Balance { get; set; }
        public decimal LockedBalance { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? CreatedTimestamp { get; set; }
        public byte? CreatedBy { get; set; }
        public DateTime? ModifiedTimestamp { get; set; }
        public byte? ModifiedBy { get; set; }

        public virtual Branch Branch { get; set; }
        public virtual Teller CreatedByNavigation { get; set; }
        public virtual Teller ModifiedByNavigation { get; set; }
        public virtual AccountCustomerMapping AccountCustomerMapping { get; set; }
        public virtual ICollection<Transaction> Transaction { get; set; }
    }
}

﻿using Infosys.DBFirstCore.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Infosys.DBFirstCore.DataAccessLayer
{
    public class OFD_Repository
    {
        public int Test { get; set; }
        private readonly OFD_Context _context;
        public OFD_Repository(OFD_Context context)
        {
            _context = context;
        }
        public OFD_Repository()
        {
            _context = new OFD_Context();
        }

        #region Library for MVC/Services Demo

        #region-To get all product details
        public List<Products> OFD_GetProducts()
        {
            List<Products> lstProducts = null;
            try
            {
                lstProducts = (from p in _context.Products
                               orderby p.ProductId
                               select p).ToList();
            }
            catch (Exception e)
            {
                lstProducts = null;
            }
            return lstProducts;
        }
        #endregion

        public List<Products> OFD_GetProductsByCategory(int catId)
        {
            List<Products> lstProducts = null;
            try
            {
                lstProducts = (from p in _context.Products where p.CategoryId==catId
                               orderby p.ProductId
                               select p).ToList();
            }
            catch (Exception e)
            {
                lstProducts = null;
            }
            return lstProducts;

        }


        #region-To get a product detail by using ProductId
        public Products OFD_GetProductDetails(string productId)
        {
            Products product = new Products();
            try
            {
                product = (from p in _context.Products
                           where p.ProductId.Equals(productId)
                           select p).FirstOrDefault();
            }
            catch (Exception)
            {
                product = null;
            }
            return product;
        }
        #endregion

        #region- To generate new product id
        public string OFD_GenerateNewProductId()
        {
            string productId;
            try
            {
                productId = (from p in _context.Products
                             select
  OFD_Context.ufn_GenerateNewProductId()).FirstOrDefault();
            }
            catch (Exception)
            {
                productId = null;
            }
            return productId;
        }
        #endregion

        #region- To add a new product
        public bool OFD_AddProduct(Products product)
        {
            bool status = false;
            try
            {
                Products prodObj = new Products();
                prodObj.ProductId = OFD_GenerateNewProductId();
                prodObj.ProductName = product.ProductName;
                prodObj.CategoryId = product.CategoryId;
                prodObj.Price = product.Price;
                prodObj.QuantityAvailable = product.QuantityAvailable;
                _context.Products.Add(prodObj);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region- To update the existing product details
        public bool OFD_UpdateProduct(Products prod)
        {
            bool status = false;
            try
            {
                var product = (from prdct in _context.Products
                               where prdct.ProductId == prod.ProductId
                               select prdct).FirstOrDefault<Products>();
                if (product != null)
                {
                    product.ProductId = prod.ProductId;
                    product.ProductName = prod.ProductName;
                    product.Price = prod.Price;
                    product.QuantityAvailable = prod.QuantityAvailable;
                    product.CategoryId = prod.CategoryId;
                    _context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region-To delete a existing product
        public bool OFD_DeleteProduct(string prodId)
        {
            bool status = false;
            try
            {
                var product = (from prdct in _context.Products
                               where prdct.ProductId == prodId
                               select prdct).FirstOrDefault<Products>();
                _context.Products.Remove(product);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion

        public List<string> OFD_FetchTopProducts()
        {
            List<string> productList = new List<string>();
            try
            {
                var list = (from c in _context.PurchaseDetails
                            join p in _context.Products on
                            c.Product equals p.ProductId
                            select p.ProductName).Distinct().ToList<string>();
                if (list.Count > 3)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        productList.Add(list[i]);
                    }
                }
                else
                {
                    productList = list;
                }

            }
            catch
            {

                productList = null;
            }
            return productList;
        }

        public string OFD_GetNextProductId()
        {
            string productId = _context.Products.OrderByDescending(x => x.ProductId).Select(x => x.ProductId).FirstOrDefault().ToString();
            int id = Convert.ToInt32(productId.Substring(1, productId.Length - 1)) + 1;
            return "P" + id.ToString();
        }

        public List<string> OFD_FetchTopProducts(string emailId)
        {
            List<string> productList = new List<string>();
            try
            {
                var list = (from c in _context.PurchaseDetails
                            join p in _context.Products on
                            c.Product equals p.ProductId
                            where c.EmailId == emailId
                            select p.ProductName).Distinct().ToList<string>();
                if (list.Count > 3)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        productList.Add(list[i]);
                    }
                }
                else
                {
                    productList = list;
                }

            }
            catch
            {

                productList = null;
            }
            return productList;
        }

        public string OFD_GetRoleName(int roleId)
        {
            try
            {
                var roleName = _context.Roles.Where(x => x.RoleId == roleId).Select(x => x.RoleName).FirstOrDefault();
                return roleName;
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion-Demo

        #region Library for MVC/Services Exercise

        #region-To get all category details
        public List<Categories> OFD_GetCategories()
        {
            List<Categories> lstCategories = null;
            try
            {
                lstCategories = (from c in _context.Categories
                                 orderby c.CategoryId ascending
                                 select c).ToList<Categories>();
            }
            catch (Exception)
            {
                lstCategories = null;
            }
            return lstCategories;
        }
        #endregion

        #region get a category detail by using CategoryId
        public Categories OFD_GetCategoryDetails(string catId)
        {
            Categories categories = new Categories();
            try
            {
                categories = (from p in _context.Categories
                              where p.CategoryId.Equals(catId)
                              select p).FirstOrDefault();
            }
            catch (Exception)
            {
                categories = null;
            }
            return categories;
        }
        #endregion

        #region-To generate new category id
        public byte OFD_GenerateNewCategoryId()
        {
            byte categoryId;
            try
            {
                var newCategoryId = (from p in _context.Categories select OFD_Context.ufn_GenerateNewCategoryId()).FirstOrDefault();
                categoryId = Convert.ToByte(newCategoryId);
            }
            catch (Exception ex)
            {
                categoryId = 0;
            }
            return categoryId;

        }
        #endregion

        #region-To add a new category
        public bool OFD_AddCategory(string categoryName)
        {
            bool status = false;
            try
            {
                Categories categories = new Categories();
                categories.CategoryName = categoryName;
                _context.Categories.Add(categories);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region-To update the existing category details
        public bool OFD_UpdateCategory(Categories categ)
        {
            bool status = false;
            try
            {
                var category = (from ctgry in _context.Categories
                                where ctgry.CategoryId == categ.CategoryId
                                select ctgry).FirstOrDefault<Categories>();
                //Categories category = context.Categories.Where(e => e.CategoryId == categ.CategoryId).FirstOrDefault<Categories>();
                if (category != null)
                {
                    category.CategoryName = categ.CategoryName;
                    _context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region-To delete a existing category
        public bool OFD_DeleteCategory(byte categID)
        {
            bool status = false;
            try
            {
                var category = (from ctgry in _context.Categories
                                where ctgry.CategoryId == categID
                                select ctgry).FirstOrDefault<Categories>();
                _context.Categories.Remove(category);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #endregion

        #region Methods for teler database



        public List<Transaction> OFD_GetSpecificTransactionDetails(string createdBy)
        {
            List<Transaction> transaction = new List<Transaction>();
            try
            {

                transaction = (from p in _context.Transaction
                               where p.CreatedBy.Equals(createdBy)
                               select p).ToList();
            }
            catch (Exception)
            {
                transaction = null;
            }
            return transaction;
        }



        public List<Transaction> OFD_GetTransactionDetails()
        {
            List<Transaction> transaction = new List<Transaction>();
            try
            {
                transaction = (from p in _context.Transaction
                               select p).ToList();
            }
            catch (Exception)
            {
                transaction = null;
            }
            return transaction;
        }
        public Customer OFD_GetCustomerDetails(int customerId)
        {
            Customer customer = new Customer();
            try
            {
                customer = (from p in _context.Customer
                            where p.CustomerId.Equals(customerId)
                            select p).FirstOrDefault();
            }
            catch (Exception)
            {
                customer = null;
            }
            return customer;
        }

        public bool OFD_Users(Users user)
        {
            bool status = true;
            try
            {
                string[] tempMail = { "0845.ru", "0box.eu", "0clickemail.com", "0n0ff.net", "0nelce.com", "0v.ro", "0w.ro", "0wnd.net", "0wnd.org", "0x207.info", "1-8.biz", "1000rebates.stream", "100likers.com", "10mail.com", "10mail.org", "10minut.com.pl", "10minut.xyz", "10minutemail.be", "10minutemail.cf", "10minutemail.co.uk", "10minutemail.co.za", "10minutemail.com", "10minutemail.de", "10minutemail.ga", "10minutemail.gq", "10minutemail.ml",
                    "10minutemail.net", "10minutemail.nl", "10minutemail.pro", "10minutemail.us", "10minutemailbox.com", "10minutemails.in", "10minutenemail.de", "10minutesmail.com", "10minutesmail.fr", "10minutmail.pl", "10x9.com", "11163.com", "123-m.com", "12hosting.net", "12houremail.com", "12minutemail.com", "12minutemail.net", "12storage.com", "140unichars.com", "147.cl", "14n.co.uk", "15qm.com", "1blackmoon.com", "1ce.us", "1chuan.com", "1clck2.com", "1fsdfdsfsdf.tk", "1mail.ml", "1pad.de", "1st-forms.com", "1to1mail.org", "1usemail.com", "1webmail.info", "1zhuan.com", "2.0-00.usa.cc", "20email.eu", "20email.it", "20mail.eu", "20mail.in", "20mail.it", "20minutemail.com", "20minutemail.it", "20mm.eu", "2120001.net",
                    "21cn.com", "24hourmail.com", "24hourmail.net", "2anom.com", "2ether.net", "2fdgdfgdfgdf.tk", "2odem.com", "2prong.com", "2wc.info", "300book.info", "30mail.ir", "30minutemail.com", "30wave.com", "3202.com", "333.igg.biz", "33mail.com", "36ru.com", "3d-painting.com", "3l6.com", "3mail.ga", "3trtretgfrfe.tk", "4-n.us", "4057.com", "418.dk", "42o.org", "4gfdsgfdgfd.tk", "4mail.cf", "4mail.ga", "4tb.host", "4warding.com",
                    "4warding.net", "4warding.org", "55hosting.net", "5ghgfhfghfgh.tk", "5gramos.com", "5july.org", "5mail.cf", "5mail.ga", "5oz.ru", "5x25.com", "5ymail.com", "60minutemail.com", "672643.net", "675hosting.com", "675hosting.net", "675hosting.org", "6hjgjhgkilkj.tk", "6ip.us", "6mail.cf", "6mail.ga", "6mail.ml", "6paq.com", "6url.com", "75hosting.com", "75hosting.net", "75hosting.org", "7days-printing.com", "7mail.ga", "7mail.ml",
                    "7tags.com", "80665.com", "8127ep.com", "8mail.cf", "8mail.ga", "8mail.ml", "99.com", "99experts.com", "9mail.cf", "9me.site", "9ox.net", "9q.ro", "a-bc.net", "a45.in", "a7996.com", "aa5zy64.com", "ab0.igg.biz", "abacuswe.us", "abakiss.com", "abcmail.email", "abilitywe.us", "abnamro.usa.cc", "abovewe.us", "absolutewe.us", "abundantwe.us", "abusemail.de", "abuser.eu", "abyssmail.com", "ac20mail.in", "academiccommunity.com",
                    "academywe.us", "acceleratewe.us", "accentwe.us", "acceptwe.us", "acclaimwe.us", "accordwe.us", "accreditedwe.us", "acentri.com", "achievementwe.us", "achievewe.us", "acornwe.us", "acrylicwe.us", "activatewe.us", "activitywe.us", "acucre.com", "acuitywe.us", "acumenwe.us", "adaptivewe.us", "adaptwe.us", "add3000.pp.ua", "addictingtrailers.com", "adeptwe.us", "adiq.eu", "aditus.info", "admiralwe.us", "ado888.biz", "adobeccepdm.com",
                    "adoniswe.us", "adpugh.org", "adsd.org", "adubiz.info", "advantagewe.us", "advantimo.com", "adventurewe.us", "adventwe.us", "advisorwe.us", "advocatewe.us", "adwaterandstir.com", "aegde.com", "aegia.net", "aegiscorp.net", "aegiswe.us", "aelo.es", "aeonpsi.com", "affiliate-nebenjob.info", "affiliatedwe.us", "affilikingz.de", "affinitywe.us", "affluentwe.us", "affordablewe.us", "afrobacon.com", "afterhourswe.us", "agedmail.com", "agendawe.us",
                    "agger.ro", "agilewe.us", "agorawe.us", "agtx.net", "aheadwe.us", "ahk.jp", "air2token.com", "airsi.de", "ajaxapp.net", "akapost.com", "akerd.com", "akgq701.com", "al-qaeda.us", "albionwe.us", "alchemywe.us", "alfaromeo.igg.biz", "aliaswe.us", "alienware13.com", "aligamel.com", "alisongamel.com", "alivance.com", "alivewe.us", "allaccesswe.us", "allamericanwe.us", "allaroundwe.us", "alldirectbuy.com", "allegiancewe.us", "allegrowe.us", "allgoodwe.us",
                    "alliancewe.us", "allinonewe.us", "allofthem.net", "alloutwe.us", "allowed.org", "alloywe.us", "allprowe.us", "allseasonswe.us", "allstarwe.us", "allthegoodnamesaretaken.org", "allurewe.us", "almondwe.us", "alph.wtf", "alpha-web.net", "alphaomegawe.us", "alpinewe.us", "altairwe.us", "altitudewe.us", "altuswe.us", "ama-trade.de", "ama-trans.de", "amadeuswe.us", "amail.club", "amail.com", "amail4.me", "amazon-aws.org", "amberwe.us", "ambiancewe.us",
                    "ambitiouswe.us", "amelabs.com", "americanawe.us", "americasbestwe.us", "americaswe.us", "amicuswe.us", "amilegit.com", "amiri.net", "amiriindustries.com", "amplewe.us", "amplifiedwe.us", "amplifywe.us", "ampsylike.com", "analogwe.us", "analysiswe.us", "analyticalwe.us", "analyticswe.us", "analyticwe.us", "anappfor.com", "anappthat.com", "andreihusanu.ro", "andthen.us", "animesos.com", "anit.ro", "ano-mail.net", "anon-mail.de", "anonbox.net", "anonmail.top",
                    "anonmails.de", "anonymail.dk", "anonymbox.com", "anonymized.org", "anonymousness.com", "anotherdomaincyka.tk", "ansibleemail.com", "anthony-junkmail.com", "antireg.com", "antireg.ru", "antispam.de", "antispam24.de", "antispammail.de", "anyalias.com", "aoeuhtns.com", "apfelkorps.de", "aphlog.com", "apkmd.com", "appc.se", "appinventor.nl", "appixie.com", "apps.dj", "arduino.hk", "ariaz.jetzt", "armyspy.com", "aron.us", "arroisijewellery.com", "art-en-ligne.pro",
                    "artman-conception.com", "arur01.tk", "arurgitu.gq", "arvato-community.de", "aschenbrandt.net", "asdasd.nl", "asdasd.ru", "ashleyandrew.com", "asiarap.usa.cc", "asorent.com", "ass.pp.ua", "astonut.tk", "astroempires.info", "asu.mx", "asu.su", "at0mik.org", "attnetwork.com", "audi.igg.biz", "augmentationtechnology.com", "ausgefallen.info", "auti.st", "autorobotica.com", "autotwollow.com", "autowb.com", "aver.com", "averdov.com", "avia-tonic.fr", "avls.pt", "awatum.de",
                    "awiki.org", "awsoo.com", "axiz.org", "axon7zte.com", "axsup.net", "azazazatashkent.tk", "azcomputerworks.com", "azmeil.tk", "b1of96u.com", "b2bx.net", "b2cmail.de", "badgerland.eu", "badoop.com", "badpotato.tk", "banit.club", "banit.me", "bareed.ws", "barryogorman.com", "bartdevos.be", "basscode.org", "bauwerke-online.com", "baxomale.ht.cx", "bazaaboom.com", "bbbbyyzz.info", "bbhost.us", "bcast.ws", "bcb.ro", "bccto.me", "bdmuzic.pw", "bearsarefuzzy.com", "beddly.com","beefmilk.com", "belamail.org", "belljonestax.com", "benipaula.org", "bestchoiceusedcar.com", "bestoption25.club", "betr.co", "bgtmail.com", "bgx.ro", "bidourlnks.com", "big1.us", "bigprofessor.so", "bigstring.com", "bigwhoop.co.za", "bij.pl", "binka.me", "binkmail.com", "binnary.com", "bio-muesli.info", "bio-muesli.net", "bione.co", "bitwhites.top", "bitymails.us", "blackmarket.to",
                    "bladesmail.net", "blip.ch", "blnkt.net", "blogmyway.org", "blogspam.ro", "blow-job.nut.cc", "bluedumpling.info", "bluewerks.com", "bnote.com", "boatmail.us", "bobmail.info", "bobmurchison.com", "bofthew.com", "bonobo.email", "bookthemmore.com", "bootybay.de", "borged.com", "borged.net", "borged.org", "bot.nu", "boun.cr", "bouncr.com", "boxformail.in", "boximail.com", "boxtemp.com.br", "brandallday.net", "brasx.org", "breakthru.com", "brefmail.com", "brennendesreich.de",
                    "briggsmarcus.com", "broadbandninja.com", "bsnow.net", "bspamfree.org", "bspooky.com", "bst-72.com", "btb-notes.com", "btc.email", "btcmail.pw", "btizet.pl", "budaya-tionghoa.com", "budayationghoa.com", "buffemail.com", "bugmenever.com", "bugmenot.com", "bulrushpress.com", "bum.net", "bumpymail.com", "bunchofidiots.com", "bund.us", "bundes-li.ga", "bunsenhoneydew.com", "burnthespam.info", "burstmail.info", "businessbackend.com", "businesssuccessislifesuccess.com", "buspad.org",
                    "bussitussi.com", "buymoreplays.com", "buyordie.info", "buyusedlibrarybooks.org", "buzzcluby.com", "byebyemail.com", "byespm.com", "byom.de", "c51vsgq.com", "cachedot.net", "californiafitnessdeals.com", "cam4you.cc", "camping-grill.info", "candymail.de", "cane.pw", "car101.pro", "carbtc.net", "cars2.club", "carsencyclopedia.com", "caseedu.tk", "casualdx.com", "cavi.mx", "cbair.com", "cc-cc.usa.cc", "cc.liamria", "cdpa.cc", "ceed.se", "cek.pm", "cellurl.com", "centermail.com",
                    "centermail.net", "cetpass.com", "cfo2go.ro", "ch.tc", "chacuo.net", "chaichuang.com", "chalupaurybnicku.cz", "chammy.info", "cheaphub.net", "cheatmail.de", "chechnya.conf.work", "chibakenma.ml", "chickenkiller.com", "chielo.com", "childsavetrust.org", "chilkat.com", "chithinh.com", "chogmail.com", "choicemail1.com", "chong-mail.com", "chong-mail.net", "chong-mail.org", "chumpstakingdumps.com", "cigar-auctions.com", "civx.org", "ckaazaza.tk", "ckiso.com", "cl-cl.org",
                    "cl0ne.net", "clandest.in", "clearwatermail.info", "clickdeal.co", "clipmail.eu", "clixser.com", "clrmail.com", "cmail.club", "cmail.com", "cmail.net", "cmail.org", "cnamed.com", "cndps.com", "cnew.ir", "cnmsg.net", "cnsds.de", "cobarekyo1.ml", "cocovpn.com", "codeandscotch.com", "codivide.com", "coieo.com", "coldemail.info", "compareshippingrates.org", "completegolfswing.com", "comwest.de", "consumerriot.com", "contbay.com", "cool.fr.nf", "coolandwacky.us", "coolimpool.org",
                    "coreclip.com", "correo.blogos.net", "cosmorph.com", "courriel.fr.nf", "courrieltemporaire.com", "coza.ro", "crankhole.com", "crapmail.org", "crastination.de", "crazespaces.pw", "crazymailing.com", "cross-law.ga", "cross-law.gq", "crossroadsmail.com", "crusthost.com", "csh.ro", "cszbl.com", "ctmailing.us", "ctos.ch", "cu.cc", "cubiclink.com", "cuirushi.org", "curlhph.tk", "curryworld.de", "cust.in", "cutout.club", "cuvox.de", "cyber-innovation.club", "cyber-phone.eu", "cylab.org",
                    "d1yun.com", "d3p.dk", "daabox.com", "dab.ro", "dacoolest.com", "daemsteam.com", "daibond.info", "daintly.com", "damai.webcam", "dammexe.net", "damnthespam.com", "dandikmail.com", "darkharvestfilms.com", "daryxfox.net", "dasdasdascyka.tk", "dash-pads.com", "dataarca.com", "datarca.com", "datazo.ca", "datum2.com", "davidkoh.net", "davidlcreative.com", "dawin.com", "dayrep.com", "dbunker.com", "dcemail.com", "ddcrew.com", "de-a.org", "deadaddress.com", "deadchildren.org", "deadfake.cf",
                    "deadfake.ga", "deadfake.ml", "deadfake.tk", "deadspam.com", "deagot.com", "dealja.com", "dealrek.com", "deekayen.us", "defomail.com", "degradedfun.net", "delayload.com", "delayload.net", "delikkt.de", "demen.ml", "dengekibunko.ga", "dengekibunko.gq", "dengekibunko.ml", "der-kombi.de", "derkombi.de", "derluxuswagen.de", "desoz.com", "despam.it", "despammed.com", "dev-null.cf", "dev-null.ga", "dev-null.gq", "dev-null.ml", "devnullmail.com", "deyom.com", "dharmatel.net", "dhm.ro", "dhy.cc", "dialogus.com",
                    "diapaulpainting.com", "digitalesbusiness.info", "digitalmariachis.com", "digitalsanctuary.com", "dildosfromspace.com", "dim-coin.com", "dingbone.com", "disaq.com", "disbox.net", "disbox.org", "discard.cf", "discard.email", "discard.ga", "discard.gq", "discard.ml", "discard.tk", "discardmail.com", "discardmail.de", "discos4.com", "disign-concept.eu", "disign-revelation.com", "dispo.in", "dispomail.eu", "disposable-email.ml", "disposable.cf", "disposable.ga", "disposable.ml", "disposableaddress.com",
                    "disposableemailaddresses.com", "disposableinbox.com", "disposablemails.com", "dispose.it", "disposeamail.com", "disposemail.com", "dispostable.com", "divad.ga", "divermail.com", "divismail.ru", "diwaq.com", "dlemail.ru", "dm.w3internet.co.uk", "dma.in-ulm.de", "dmarc.ro", "dndent.com", "dnses.ro", "doanart.com", "dob.jp", "dodgeit.com", "dodgemail.de", "dodgit.com", "dodgit.org", "dodsi.com", "doiea.com", "dolphinnet.net", "domforfb1.tk", "domforfb18.tk", "domforfb19.tk", "domforfb2.tk", "domforfb23.tk", "domforfb27.tk", "domforfb29.tk", "domforfb3.tk", "domforfb4.tk", "domforfb5.tk", "domforfb6.tk", "domforfb7.tk", "domforfb8.tk", "domforfb9.tk", "domozmail.com", "donemail.ru", "dongqing365.com", "dontreg.com", "dontsendmespam.de", "doquier.tk", "dotman.de", "dotmsg.com", "dotslashrage.com", "douchelounge.com", "dozvon-spb.ru", "dp76.com", "dr69.site", "drdrb.com", "drdrb.net", "dred.ru", "drevo.si", "drivetagdev.com", "droolingfanboy.de", "dropcake.de", "droplar.com", "dropmail.me", "dsiay.com", "dspwebservices.com", "duam.net", "duck2.club", "dudmail.com", "duk33.com", "dukedish.com", "dump-email.info", "dumpandjunk.com", "dumpmail.de", "dumpyemail.com", "durandinterstellar.com", "duskmail.com", "dwse.edu.pl", "dyceroprojects.com", "dz17.net", "e-mail.com", "e-mail.igg.biz", "e-mail.org", "e-tomarigi.com", "e3z.de", "e4ward.com", "easy-trash-mail.com", "easynetwork.info", "easytrashmail.com", "eatmea2z.club", "ebbob.com", "ebeschlussbuch.de", "ecallheandi.com", "ecolo-online.fr", "edgex.ru", "edinburgh-airporthotels.com", "edv.to", "ee1.pl", "ee2.pl", "eelmail.com", "efxs.ca", "einmalmail.de", "einrot.com", "einrot.de", "eintagsmail.de", "elearningjournal.org", "electro.mn", "elitevipatlantamodels.com", "email-fake.cf", "email-fake.com", "email-fake.ga", "email-fake.gq", "email-fake.ml", "email-fake.tk", "email-jetable.fr", "email-temp.com", "email.cbes.net", "email.net", "email60.com", "emailage.cf", "emailage.ga", "emailage.gq", "emailage.ml", "emailage.tk", "emaildienst.de", "emaildrop.io", "emailfake.ml", "emailfake.nut.cc", "emailfreedom.ml", "emailgo.de", "emailias.com", "emailigo.de", "emailinfive.com", "emailisvalid.com", "emaillime.com", "emailmiser.com", "emailna.co", "emailo.pro", "emailproxsy.com", "emailresort.com", "emails.ga", "emailsecurer.com", "emailsensei.com", "emailsingularity.net", "emailspam.cf", "emailspam.ga", "emailspam.gq", "emailspam.ml", "emailspam.tk", "emailsy.info", "emailtech.info", "emailtemporanea.com", "emailtemporanea.net", "emailtemporar.ro", "emailtemporario.com.br", "emailthe.net", "emailtmp.com", "emailto.de", "emailure.net", "emailwarden.com", "emailx.at.hm", "emailxfer.com", "emailz.cf", "emailz.ga", "emailz.gq", "emailz.ml", "emeil.in", "emeil.ir", "emeraldwebmail.com", "emil.com", "emkei.cf", "emkei.ga", "emkei.gq", "emkei.ml", "emkei.tk", "eml.pp.ua", "emlhub.com", "emlpro.com", "emltmp.com", "empireanime.ga", "emz.net", "enterto.com", "envy17.com", "epb.ro", "ephemail.net", "ephemeral.email", "eqiluxspam.ga", "ericjohnson.ml", "ero-tube.org", "esc.la", "escapehatchapp.com", "esemay.com", "esgeneri.com", "esprity.com", "estate-invest.fr", "eth2btc.info", "ether123.net", "ethereum1.top", "ethersports.org", "ethersportz.info", "etranquil.com", "etranquil.net", "etranquil.org", "euaqa.com", "evanfox.info", "evilcomputer.com", "evopo.com", "evyush.com", "exitstageleft.net", "explodemail.com", "express.net.ua", "extremail.ru", "eyepaste.com", "ez.lv", "ezehe.com", "ezfill.com", "ezstest.com", "f4k.es", "facebook-email.cf", "facebook-email.ga", "facebook-email.ml", "facebookmail.gq", "facebookmail.ml", "fackme.gq", "fadingemail.com", "faecesmail.me", "fag.wf", "failbone.com", "faithkills.com", "fake-email.pp.ua", "fake-mail.cf", "fake-mail.ga", "fake-mail.ml", "fakedemail.com", "fakeinbox.cf", "fakeinbox.com", "fakeinbox.ga", "fakeinbox.info", "fakeinbox.ml", "fakeinbox.tk", "fakeinformation.com", "fakemail.fr", "fakemailgenerator.com", "fakemailz.com", "fammix.com", "fangoh.com", "fansworldwide.de", "fantasymail.de", "farrse.co.uk", "fast-mail.fr", "fastacura.com", "fastchevy.com", "fastchrysler.com", "fasternet.biz", "fastkawasaki.com", "fastmazda.com", "fastmitsubishi.com", "fastnissan.com", "fastsubaru.com", "fastsuzuki.com", "fasttoyota.com", "fastyamaha.com", "fatflap.com", "fbma.tk", "fbmail.usa.cc", "fddns.ml", "fdfdsfds.com", "fer-gabon.org", "fettometern.com", "ficken.de", "fictionsite.com", "fightallspam.com", "figjs.com", "figshot.com", "fiifke.de", "filbert4u.com", "filberts4u.com", "film-blog.biz", "filzmail.com", "findu.pl", "fir.hk", "fivemail.de", "fixmail.tk", "fizmail.com", "flashbox.5july.org", "fleckens.hu", "flemail.ru", "flowu.com", "flu-cc.flu.cc", "flucc.flu.cc", "fluidsoft.us", "flurred.com", "fly-ts.de", "flyinggeek.net", "flyspam.com", "foobarbot.net", "footard.com", "forecastertests.com", "foreskin.cf", "foreskin.ga", "foreskin.gq", "foreskin.ml", "foreskin.tk", "forgetmail.com", "fornow.eu", "forspam.net", "forward.cat", "foxja.com", "foxtrotter.info", "fr.nf", "fr33mail.info", "fragolina2.tk", "frapmail.com", "frappina.tk", "free-email.cf", "free-email.ga", "freebabysittercam.com", "freeblackbootytube.com", "freecat.net", "freedom4you.info", "freedompop.us", "freefattymovies.com", "freelance-france.eu", "freeletter.me", "freemail.ms", "freemail.tweakly.net", "freemails.cf", "freemails.ga", "freemails.ml", "freemeil.ga", "freemeil.gq", "freemeil.ml", "freeplumpervideos.com", "freeschoolgirlvids.com", "freesistercam.com", "freeteenbums.com", "freundin.ru", "friendlymail.co.uk", "front14.org", "ftp.sh", "ftpinc.ca", "fuckedupload.com", "fuckingduh.com", "fuckme69.club", "fucknloveme.top", "fuckxxme.top", "fudgerub.com", "fuirio.com", "fulvie.com", "fun64.com", "funnycodesnippets.com", "funnymail.de", "furzauflunge.de", "fux0ringduh.com", "fxnxs.com", "fyii.de", "g14l71lb.com", "g1xmail.top", "g2xmail.top", "g3xmail.top", "g4hdrop.us", "gafy.net", "galaxy.tv", "gally.jp", "gamail.top", "gamegregious.com", "gamgling.com", "garasikita.pw", "garbagecollector.org", "garbagemail.org", "gardenscape.ca", "garizo.com", "garliclife.com", "garrymccooey.com", "gav0.com", "gawab.com", "gbcmail.win", "gbmail.top", "gcmail.top", "gdmail.top", "gedmail.win", "geekforex.com", "geew.ru", "gehensiemirnichtaufdensack.de", "geldwaschmaschine.de", "gelitik.in", "gen.uu.gl", "genderfuck.net", "geronra.com", "geschent.biz", "get-mail.cf", "get-mail.ga", "get-mail.ml", "get-mail.tk", "get.pp.ua", "get1mail.com", "get2mail.fr", "getairmail.cf", "getairmail.com", "getairmail.ga", "getairmail.gq", "getairmail.ml", "getairmail.tk", "geteit.com", "getfun.men", "getmails.eu", "getnada.com", "getnowtoday.cf", "getonemail.com", "getonemail.net", "ghosttexter.de", "giacmosuaviet.info", "giaiphapmuasam.com", "giantmail.de", "gifto12.com", "ginzi.be", "ginzi.co.uk", "ginzi.es", "ginzi.net", "ginzy.co.uk", "ginzy.eu", "girlmail.win", "girlsindetention.com", "girlsundertheinfluence.com", "gishpuppy.com", "giveh2o.info", "givmail.com", "glitch.sx", "globaltouron.com", "glubex.com", "glucosegrin.com", "gmal.com", "gmatch.org", "gmial.com", "gmx.fr.nf", "gmx1mail.top", "gmxmail.top", "gmxmail.win", "gnctr-calgary.com", "go2usa.info", "go2vpn.net", "goemailgo.com", "golemico.com", "gomail.in", "gorillaswithdirtyarmpits.com", "goround.info", "gothere.biz", "gotmail.com", "gotmail.net", "gotmail.org", "gotti.otherinbox.com", "gowikibooks.com", "gowikicampus.com", "gowikicars.com", "gowikifilms.com", "gowikigames.com", "gowikimusic.com", "gowikinetwork.com", "gowikitravel.com", "gowikitv.com", "grandmamail.com", "grandmasmail.com", "great-host.in", "greenhousemail.com", "greensloth.com", "greggamel.com", "greggamel.net", "gregorsky.zone", "gregorygamel.com", "gregorygamel.net", "grish.de", "griuc.schule", "grr.la", "gs-arc.org", "gsredcross.org", "gsrv.co.uk", "gsxstring.ga", "gudanglowongan.com", "guerillamail.biz", "guerillamail.com", "guerillamail.de", "guerillamail.info", "guerillamail.net", "guerillamail.org", "guerillamailblock.com", "guerrillamail.biz", "guerrillamail.com", "guerrillamail.de", "guerrillamail.info", "guerrillamail.net", "guerrillamail.org", "guerrillamailblock.com", "gustr.com", "gxemail.men", "gynzi.co.uk", "gynzi.es", "gynzy.at", "gynzy.es", "gynzy.eu", "gynzy.gr", "gynzy.info", "gynzy.lt", "gynzy.mobi", "gynzy.pl", "gynzy.ro", "gynzy.sk", "gzb.ro", "h8s.org", "habitue.net", "hacccc.com", "hackersquad.tk", "hackthatbit.ch", "hahawrong.com", "haida-edu.cn", "haltospam.com", "hangxomcuatoilatotoro.ml", "harakirimail.com", "haribu.com", "hartbot.de", "hasanmail.ml", "hat-geld.de", "hatespam.org", "hawrong.com", "haydoo.com", "hazelnut4u.com", "hazelnuts4u.com", "hazmatshipping.org", "hccmail.win", "headstrong.de", "heathenhammer.com", "heathenhero.com", "hecat.es", "hellodream.mobi", "helloricky.com", "helpinghandtaxcenter.org", "heros3.com", "herp.in", "herpderp.nl", "hezll.com", "hi5.si", "hiddentragedy.com", "hidebox.org", "hidebusiness.xyz", "hidemail.de", "hidemail.pro", "hidemail.us", "hidzz.com", "highbros.org", "hiltonvr.com", "hmail.us", "hmamail.com", "hmh.ro", "hoanggiaanh.com", "hoanglong.tech", "hochsitze.com", "hola.org", "holl.ga", "honor-8.com", "hopemail.biz", "hornyalwary.top", "hostcalls.com", "hostlaba.com", "hot-mail.cf", "hot-mail.ga", "hot-mail.gq", "hot-mail.ml", "hot-mail.tk", "hotmai.com", "hotmailproduct.com", "hotmial.com", "hotpop.com", "hotprice.co", "housat.com", "hpc.tw", "hs.vc", "ht.cx", "huangniu8.com", "hukkmu.tk", "hulapla.de", "humaility.com", "humn.ws.gy", "hungpackage.com", "hushmail.cf", "huskion.net", "hvastudiesucces.nl", "hwsye.net", "i-phone.nut.cc", "i2pmail.org", "i6.cloudns.cc", "i6.cloudns.cx", "iaoss.com", "ibnuh.bz", "icantbelieveineedtoexplainthisshit.com", "icx.in", "icx.ro", "idx4.com", "ieatspam.eu", "ieatspam.info", "ieh-mail.de", "iencm.com", "ige.es", "ignoremail.com", "ihateyoualot.info", "ihazspam.ca", "iheartspam.org", "ikbenspamvrij.nl", "illistnoise.com", "ilovespam.com", "imails.info", "imgof.com", "imgv.de", "immo-gerance.info", "imstations.com", "imul.info", "inbax.tk", "inbound.plus", "inbox.si", "inbox2.info", "inboxalias.com", "inboxbear.com", "inboxclean.com", "inboxclean.org", "inboxdesign.me", "inboxed.im", "inboxed.pw", "inboxproxy.com", "inboxstore.me", "inclusiveprogress.com", "incognitomail.com", "incognitomail.net", "incognitomail.org", "incq.com", "ind.st", "indieclad.com", "indirect.ws", "indomaed.pw", "indomina.cf", "indoserver.stream", "indosukses.press", "ineec.net", "infocom.zp.ua", "inggo.org", "inmynetwork.tk", "inoutmail.de", "inoutmail.eu", "inoutmail.info", "inoutmail.net", "insanumingeniumhomebrew.com", "insorg-mail.info", "instant-mail.de", "instantblingmail.info", "instantemailaddress.com", "instantmail.fr", "internetoftags.com", "interstats.org", "intersteller.com", "investore.co", "iozak.com", "ip4.pp.ua", "ip6.li", "ip6.pp.ua", "ipoo.org", "ippandansei.tk", "ipsur.org", "irabops.com", "irc.so", "irish2me.com", "iroid.com", "ironiebehindert.de", "irssi.tv", "is.af", "isdaq.com", "isosq.com", "istii.ro", "isukrainestillacountry.com", "it7.ovh", "italy-mail.com", "itunesgiftcodegenerator.com", "iuemail.men", "iwi.net", "ixx.io", "j-p.us", "j8k2.usa.cc", "jafps.com", "jajxz.com", "jamesbond.flu.cc", "jamesbond.igg.biz", "jamesbond.nut.cc", "jamesbond.usa.cc", "janproz.com", "jaqis.com", "jdmadventures.com", "jdz.ro", "je-recycle.info", "jeie.igg.biz", "jellow.ml", "jellyrolls.com", "jet-renovation.fr", "jetable.com", "jetable.fr.nf", "jetable.net", "jetable.org", "jetable.pp.ua", "jmail.ovh", "jmail.ro", "jnxjn.com", "jobbikszimpatizans.hu", "jobposts.net", "jobs-to-be-done.net", "joelpet.com", "joetestalot.com", "jopho.com", "joseihorumon.info", "josse.ltd", "jourrapide.com", "jpco.org", "jsrsolutions.com", "jumonji.tk", "jungkamushukum.com", "junk.to", "junk1e.com", "junkmail.ga", "junkmail.gq", "justemail.ml", "juyouxi.com", "jwork.ru", "kademen.com", "kadokawa.cf", "kadokawa.ga", "kadokawa.gq", "kadokawa.ml", "kadokawa.tk", "kakadua.net", "kalapi.org", "kamsg.com", "kaovo.com", "kappala.info", "karatraman.ml", "kariplan.com", "kartvelo.com", "kasmail.com", "kaspop.com", "katztube.com", "kazelink.ml", "kcrw.de", "keepmymail.com", "keinhirn.de", "keipino.de", "kekita.com", "kemptvillebaseball.com", "kennedy808.com", "kiani.com", "killmail.com", "killmail.net", "kimsdisk.com", "kingsq.ga", "kiois.com", "kir.ch.tc", "kiryubox.cu.cc", "kismail.ru", "kisstwink.com", "kitnastar.com", "klassmaster.com", "klassmaster.net", "klick-tipp.us", "klipschx12.com", "kloap.com", "kludgemush.com", "klzlk.com", "kmhow.com", "knol-power.nl", "kommunity.biz", "kon42.com", "kook.ml", "kopagas.com", "kopaka.net", "kosmetik-obatkuat.com", "kostenlosemailadresse.de", "koszmail.pl", "kpooa.com", "krd.ag", "krsw.tk", "krypton.tk", "ks87.igg.biz", "ks87.usa.cc", "ksmtrck.tk", "kuhrap.com", "kulmeo.com", "kulturbetrieb.info", "kurzepost.de", "kwift.net", "kwilco.net", "kyal.pl", "kyois.com", "l-c-a.us", "l33r.eu", "l6factors.com", "labetteraverouge.at", "lacedmail.com", "lackmail.net", "lackmail.ru", "lacto.info", "lags.us", "lain.ch", "lajoska.pe.hu", "lak.pp.ua", "lakelivingstonrealestate.com", "lakqs.com", "landmail.co", "laoeq.com", "larisia.com", "last-chance.pro", "lastmail.co", "lastmail.com", "lawlita.com", "lazyinbox.com", "lazyinbox.us", "ldop.com", "ldtp.com", "lee.mx", "leeching.net", "legalrc.loan", "lellno.gq", "lenovog4.com", "letmeinonthis.com", "letthemeatspam.com", "lez.se", "lgxscreen.com", "lhsdv.com", "liamcyrus.com", "lifebyfood.com", "lifetimefriends.info", "lifetotech.com", "ligsb.com", "lillemap.net", "lilo.me", "lindenbaumjapan.com", "link2mail.net", "linkedintuts2016.pw", "linuxmail.so", "litedrop.com", "liveradio.tk", "lkgn.se", "llogin.ru", "loadby.us", "loan101.pro", "loaoa.com", "loapq.com", "locanto1.club", "locantofuck.top", "locantowsite.club", "locomodev.net", "login-email.cf", "login-email.ga", "login-email.ml", "login-email.tk", "logular.com", "loh.pp.ua", "loin.in", "lol.ovpn.to", "lolfreak.net", "lolmail.biz", "lookugly.com", "lopl.co.cc", "lordsofts.com", "lortemail.dk", "losemymail.com", "lovemeet.faith", "lovemeleaveme.com", "lpfmgmtltd.com", "lr7.us", "lr78.com", "lroid.com", "lru.me", "luckymail.org", "lukecarriere.com", "lukemail.info", "lukop.dk", "luv2.us", "lyfestylecreditsolutions.com", "lzoaq.com", "m21.cc", "m4ilweb.info", "maboard.com", "macromaid.com", "macromice.info", "magamail.com", "maggotymeat.ga", "magicbox.ro", "maidlow.info", "mail-easy.fr", "mail-filter.com", "mail-owl.com", "mail-temporaire.com", "mail-temporaire.fr", "mail-tester.com", "mail.by", "mail.mezimages.net", "mail.wtf", "mail0.ga", "mail114.net", "mail1a.de", "mail21.cc", "mail22.club", "mail2rss.org", "mail333.com", "mail4trash.com", "mail666.ru", "mail707.com", "mail72.com", "mailback.com", "mailbidon.com", "mailbiz.biz", "mailblocks.com", "mailbox52.ga", "mailbox80.biz", "mailbox82.biz", "mailbox87.de", "mailbox92.biz", "mailboxy.fun", "mailbucket.org", "mailcat.biz", "mailcatch.com", "mailchop.com", "mailcker.com", "mailde.de", "mailde.info", "maildrop.cc", "maildrop.cf", "maildrop.ga", "maildrop.gq", "maildrop.ml", "maildu.de", "maildx.com", "maileater.com", "mailed.in", "mailed.ro", "maileimer.de", "maileme101.com", "mailexpire.com", "mailf5.com", "mailfa.tk", "mailfall.com", "mailforspam.com", "mailfree.ga", "mailfree.gq", "mailfree.ml", "mailfreeonline.com", "mailfs.com", "mailguard.me", "mailgutter.com", "mailhazard.com", "mailhazard.us", "mailhex.com", "mailhz.me", "mailimate.com", "mailin8r.com", "mailinatar.com", "mailinater.com", "mailinator.co.uk", "mailinator.com", "mailinator.gq", "mailinator.info", "mailinator.net", "mailinator.org", "mailinator.us", "mailinator.usa.cc", "mailinator0.com", "mailinator1.com", "mailinator2.com", "mailinator2.net", "mailinator3.com", "mailinator4.com", "mailinator5.com", "mailinator6.com", "mailinator7.com", "mailinator8.com", "mailinator9.com", "mailincubator.com", "mailismagic.com", "mailita.tk", "mailjunk.cf", "mailjunk.ga", "mailjunk.gq", "mailjunk.ml", "mailjunk.tk", "mailmate.com", "mailme.gq", "mailme.ir", "mailme.lv", "mailme24.com", "mailmetrash.com", "mailmoat.com", "mailmoth.com", "mailms.com", "mailna.biz", "mailna.co", "mailna.in", "mailna.me", "mailnator.com", "mailnesia.com", "mailnull.com", "mailonaut.com", "mailorc.com", "mailorg.org", "mailox.fun", "mailpick.biz", "mailpooch.com", "mailpress.gq", "mailproxsy.com", "mailquack.com", "mailrock.biz", "mailsac.com", "mailscrap.com", "mailseal.de", "mailshell.com", "mailsiphon.com", "mailslapping.com", "mailslite.com", "mailsucker.net", "mailtechx.com", "mailtemp.info", "mailtemporaire.com", "mailtemporaire.fr", "mailtome.de", "mailtothis.com", "mailtraps.com", "mailtrash.net", "mailtrix.net", "mailtv.net", "mailtv.tv", "mailzi.ru", "mailzilla.com", "mailzilla.org", "mailzilla.orgmbx.cc", "mainerfolg.info", "makemenaughty.club", "makemetheking.com", "malahov.de", "malayalamdtp.com", "mandraghen.cf", "manifestgenerator.com", "mansiondev.com", "manybrain.com", "markmurfin.com", "masonline.info", "maswae.world", "matamuasu.ga", "matchpol.net", "matra.site", "mbx.cc", "mcache.net", "mciek.com", "mdhc.tk", "mebelnu.info", "mechanicalresumes.com", "meepsheep.eu", "mega.zik.dj", "meinspamschutz.de",
                    "meltedbrownies.com", "meltmail.com", "memsg.site", "messagebeamer.de", "messwiththebestdielikethe.rest", "mezimages.net", "mfsa.info", "mfsa.ru", "miaferrari.com", "miauj.com", "midcoastcustoms.com", "midcoastcustoms.net", "midcoastsolutions.com", "midcoastsolutions.net", "midlertidig.com", "midlertidig.net", "midlertidig.org", "mierdamail.com", "migmail.net", "migmail.pl", "migumail.com", "mihep.com", "mijnhva.nl", "milk.gage.ga", "ministry-of-silly-walks.de", "minsmail.com", "mintemail.com", "misterpinball.de", "mji.ro", "mjukglass.nu", "mkpfilm.com", "ml8.ca", "mm.my", "mm5.se", "mnode.me", "moakt.co", "moakt.com", "moakt.ws", "mobileninja.co.uk", "mobilevpn.top", "moburl.com", "mockmyid.com", "moeri.org", "mohmal.com", "mohmal.im", "mohmal.in", "mohmal.tech", "molms.com", "momentics.ru", "monachat.tk", "monadi.ml", "moncourrier.fr.nf", "monemail.fr.nf", "moneypipe.net", "monmail.fr.nf", "monumentmail.com", "moonwake.com", "moot.es", "mor19.uu.gl", "moreawesomethanyou.com", "moreorcs.com", "morriesworld.ml", "morsin.com", "moruzza.com", "motique.de", "mountainregionallibrary.net", "mox.pp.ua", "moza.pl", "mozej.com", "mp-j.ga", "mp-j.igg.biz", "mp.igg.biz", "mr24.co", "msgos.com", "mspeciosa.com", "msrc.ml", "mswork.ru", "msxd.com", "mt2009.com", "mt2014.com", "mt2015.com", "mtmdev.com", "muathegame.com", "muchomail.com", "mucincanon.com", "muehlacker.tk", "munoubengoshi.gq", "mutant.me", "mvrht.com", "mvrht.net", "mwarner.org", "mxfuel.com", "my10minutemail.com", "mybitti.de", "mycleaninbox.net", "mycorneroftheinter.net", "myde.ml", "mydemo.equipment", "myecho.es", "myemailboxy.com", "mygeoweb.info", "myindohome.services", "myinterserver.ml", "mykickassideas.com", "mymail-in.net", "mymail90.com", "mymailoasis.com", "mynetstore.de", "myopang.com", "mypacks.net", "mypartyclip.de", "myphantomemail.com", "mysamp.de", "myspaceinc.com", "myspaceinc.net", "myspaceinc.org", "myspacepimpedup.com", "myspamless.com", "mystvpn.com", "mytemp.email", "mytempemail.com", "mytempmail.com", "mytrashmail.com", "mywarnernet.net", "myzx.com", "n1nja.org", "nabuma.com", "nada.email", "nada.ltd", "nakedtruth.biz", "nanonym.ch", "nationalgardeningclub.com", "nawmin.info", "nbox.notif.me", "nbzmr.com", "negated.com", "neomailbox.com", "nepwk.com", "nervmich.net", "nervtmich.net", "netmails.com", "netmails.net", "netricity.nl", "netris.net", "netviewer-france.com", "netzidiot.de", "nevermail.de", "newbpotato.tk", "newideasfornewpeople.info", "next.ovh", "nextstopvalhalla.com", "nezdiro.org", "nezzart.com", "nfast.net", "nguyenusedcars.com", "nh3.ro", "nice-4u.com", "nicknassar.com", "nincsmail.com", "nincsmail.hu", "niwl.net", "nm7.cc", "nmail.cf", "nnh.com", "nnot.net", "nnoway.ru", "no-spam.ws", "no-ux.com", "noblepioneer.com", "nobugmail.com", "nobulk.com", "nobuma.com", "noclickemail.com", "nodezine.com", "nogmailspam.info", "noicd.com", "nokiamail.com", "nolemail.ga", "nomail.cf", "nomail.ga", "nomail.pw", "nomail.xl.cx", "nomail2me.com", "nomorespamemails.com", "nonspam.eu", "nonspammer.de", "nonze.ro", "noref.in", "norseforce.com", "nospam.ze.tc", "nospam4.us", "nospamfor.us", "nospamthanks.info", "nothingtoseehere.ca", "notmailinator.com", "notrnailinator.com", "notsharingmy.info", "now.im", "nowhere.org", "nowmymail.com", "nowmymail.net", "ntlhelp.net", "nubescontrol.com", "nullbox.info", "nurfuerspam.de", "nut-cc.nut.cc", "nutcc.nut.cc", "nutpa.net", "nuts2trade.com", "nwldx.com", "nwytg.com", "nwytg.net", "ny7.me", "nypato.com", "nyrmusic.com", "o2stk.org", "o7i.net", "oalsp.com", "obfusko.com", "objectmail.com", "obobbo.com", "obxpestcontrol.com", "odaymail.com", "odem.com", "odnorazovoe.ru", "oepia.com", "oerpub.org", "offshore-proxies.net", "ohaaa.de", "ohi.tw", "oing.cf", "okclprojects.com", "okrent.us", "okzk.com", "olypmall.ru", "omail.pro", "omnievents.org", "one-time.email", "one2mail.info", "oneoffemail.com", "oneoffmail.com", "onewaymail.com", "onlatedotcom.info", "online.ms", "onlineidea.info", "onqin.com", "ontyne.biz", "oohioo.com", "oolus.com", "oopi.org", "opayq.com", "opendns.ro", "opmmedia.ga", "opp24.com", "oranek.com", "ordinaryamerican.net", "oreidresume.com", "oroki.de", "oshietechan.link", "otherinbox.com", "ourklips.com", "ourpreviewdomain.com", "outlawspam.com", "outmail.win", "ovi.usa.cc", "ovpn.to", "owlpic.com", "ownsyou.de", "oxopoha.com", "ozyl.de", "p33.org", "p71ce1m.com", "pa9e.com", "pachilly.com", "pagamenti.tk", "pakadebu.ga", "pancakemail.com", "paplease.com", "parlimentpetitioner.tk", "pastebitch.com", "patonce.com", "pavilionx2.com", "payperex2.com", "pcusers.otherinbox.com", "pecinan.com", "pecinan.net", "pecinan.org", "penisgoes.in", "penoto.tk", "pepbot.com", "peterdethier.com", "petrzilka.net", "pfui.ru", "photo-impact.eu", "photomark.net", "phpbb.uu.gl", "pi.vu", "piaa.me", "pig.pp.ua", "pii.at", "piki.si", "pimpedupmyspace.com", "pinehill-seattle.org", "pingir.com", "pisls.com", "pjjkp.com", "plexolan.de", "plhk.ru", "ploae.com", "plw.me", "pojok.ml", "pokemail.net", "pokiemobile.com", "polarkingxx.ml", "politikerclub.de", "pooae.com", "poofy.org", "pookmail.com", "poopiebutt.club", "popesodomy.com", "popgx.com", "porsh.net", "posdz.com", "posta.store", "postacin.com", "postonline.me", "poutineyourface.com", "powered.name", "powlearn.com", "ppetw.com", "pqoia.com", "predatorrat.cf", "predatorrat.ga", "predatorrat.gq", "predatorrat.ml", "predatorrat.tk", "premium-mail.fr", "primabananen.net", "privacy.net", "privatdemail.net", "privy-mail.com", "privy-mail.de", "privymail.de", "pro-tag.org", "procrackers.com", "projectcl.com", "proprietativalcea.ro", "propscore.com", "protempmail.com", "proxymail.eu", "proxyparking.com", "prtnx.com", "prtz.eu", "psh.me", "psles.com", "psoxs.com", "puglieisi.com", "puji.pro", "punkass.com", "purcell.email", "purelogistics.org", "put2.net", "puttanamaiala.tk", "putthisinyourspamdatabase.com", "pwrby.com", "qasti.com", "qbfree.us", "qc.to", "qibl.at", "qipmail.net", "qiq.us", "qisdo.com", "qisoa.com", "qoika.com", "qq.my", "qsl.ro", "qtum-ico.com", "quadrafit.com", "quickinbox.com", "quickmail.nl", "ququb.com", "qvy.me", "qwickmail.com", "r4nd0m.de", "ra3.us", "rabin.ca", "rabiot.reisen", "radiku.ye.vc", "raetp9.com", "rainbowly.ml", "raketenmann.de", "rancidhome.net", "randomail.net", "raqid.com", "rax.la", "raxtest.com", "razemail.com", "rbb.org", "rcasd.com", "rcpt.at", "rdklcrv.xyz", "re-gister.com", "reality-concept.club", "reallymymail.com", "realtyalerts.ca", "rebates.stream", "receiveee.com", "recipeforfailure.com", "recode.me", "reconmail.com", "recyclemail.dk", "reddit.usa.cc", "redfeathercrow.com", "reftoken.net", "regbypass.com", "regspaces.tk", "rejectmail.com", "rejo.technology", "reliable-mail.com", "remail.cf", "remail.ga", "remarkable.rocks", "remote.li", "reptilegenetics.com", "resgedvgfed.tk", "revolvingdoorhoax.org", "rhyta.com", "richfinances.pw", "riddermark.de", "risingsuntouch.com", "riski.cf", "rklips.com", "rkomo.com", "rma.ec", "rmqkr.net", "rnailinator.com", "ro.lt", "robertspcrepair.com", "rollindo.agency", "ronnierage.net", "rootfest.net", "rotaniliam.com", "rowe-solutions.com", "royal.net", "royaldoodles.org", "rppkn.com", "rsvhr.com", "rtrtr.com", "rtskiya.xyz", "rudymail.ml", "ruffrey.com", "rumgel.com", "runi.ca", "rupayamail.com", "rustydoor.com", "rvb.ro", "s0ny.net", "s33db0x.com", "sabrestlouis.com", "sackboii.com", "safaat.cf", "safermail.info", "safersignup.de", "safetymail.info", "safetypost.de", "saharanightstempe.com", "salmeow.tk", "samsclass.info", "sandcars.net", "sandelf.de", "sandwhichvideo.com", "sanfinder.com", "sanim.net", "sanstr.com", "sast.ro", "satisfyme.club", "satukosong.com", "sausen.com", "saynotospams.com", "scatmail.com", "scay.net", "schachrol.com", "schafmail.de", "schmeissweg.tk", "schrott-email.de", "sd3.in", "secmail.pw", "secretemail.de", "secure-mail.biz", "secure-mail.cc", "secured-link.net", "securehost.com.es", "securemail.flu.cc", "securemail.igg.biz", "securemail.nut.cc", "securemail.usa.cc", "seekapps.com", "seekjobs4u.com", "sejaa.lv", "selfdestructingmail.com", "selfdestructingmail.org", "send22u.info", "sendfree.org", "sendingspecialflyers.com", "sendspamhere.com", "senseless-entertainment.com", "server.ms", "services391.com", "sexforswingers.com", "sexical.com", "sexyalwasmi.top", "shalar.net", "sharedmailbox.org", "sharklasers.com", "shhmail.com", "shhuut.org", "shieldedmail.com", "shieldemail.com", "shiftmail.com", "shipfromto.com", "shiphazmat.org", "shipping-regulations.com", "shippingterms.org", "shitaway.tk", "shitmail.de", "shitmail.me", "shitmail.org", "shitware.nl", "shmeriously.com", "shortmail.net", "shotmail.ru", "showslow.de", "shrib.com", "shut.name", "shut.ws", "sify.com", "sikux.com", "siliwangi.ga", "simpleitsecurity.info", "sin.cl", "sinfiltro.cl", "singlespride.com", "sinnlos-mail.de", "sino.tw", "siteposter.net", "sizzlemctwizzle.com", "sjuaq.com", "skeefmail.com", "skrx.tk", "sky-inbox.com", "sky-ts.de", "slapsfromlastnight.com", "slaskpost.se", "slave-auctions.net", "slippery.email", "slipry.net", "slopsbox.com", "slothmail.net", "slushmail.com", "sluteen.com", "sly.io", "smallker.tk", "smap.4nmv.ru", "smapfree24.com", "smapfree24.de", "smapfree24.eu", "smapfree24.info", "smapfree24.org", "smarttalent.pw", "smashmail.de", "smellfear.com", "smellrear.com", "smellypotato.tk", "smtp99.com", "smwg.info", "snakemail.com", "snapwet.com", "sneakmail.de", "social-mailer.tk", "socialfurry.org", "sofimail.com", "sofort-mail.de", "sofortmail.de", "softpls.asia", "sogetthis.com", "sohai.ml", "sohus.cn", "soioa.com", "soisz.com", "solar-impact.pro", "solvemail.info", "solventtrap.wiki", "sonshi.cf", "soodmail.com", "soodomail.com", "soodonims.com", "soon.it", "spam-be-gone.com", "spam.2012-2016.ru", "spam.la", "spam.org.es", "spam.su", "spam4.me", "spamail.de", "spamarrest.com", "spamavert.com", "spambob.com", "spambob.net", "spambob.org", "spambog.com", "spambog.de", "spambog.net", "spambog.ru", "spambooger.com", "spambox.info", "spambox.irishspringrealty.com", "spambox.me", "spambox.org", "spambox.us", "spamcero.com", "spamcon.org", "spamcorptastic.com", "spamcowboy.com", "spamcowboy.net", "spamcowboy.org", "spamday.com", "spamdecoy.net", "spamex.com", "spamfighter.cf", "spamfighter.ga", "spamfighter.gq", "spamfighter.ml", "spamfighter.tk", "spamfree.eu", "spamfree24.com", "spamfree24.de", "spamfree24.eu", "spamfree24.info", "spamfree24.net", "spamfree24.org", "spamgoes.in", "spamherelots.com", "spamhereplease.com", "spamhole.com", "spamify.com", "spaminator.de", "spamkill.info", "spaml.com", "spaml.de", "spamlot.net", "spammotel.com", "spamobox.com", "spamoff.de", "spamsalad.in", "spamslicer.com", "spamsphere.com", "spamspot.com", "spamstack.net", "spamthis.co.uk", "spamthisplease.com", "spamtrail.com", "spamtrap.ro", "spamtroll.net", "spamwc.cf", "spamwc.ga", "spamwc.gq", "spamwc.ml", "speed.1s.fr", "speedgaus.net", "sperma.cf", "spikio.com", "spindl-e.com", "spoofmail.de", "spr.io", "spritzzone.de", "spybox.de", "squizzy.de", "squizzy.net", "sroff.com", "sry.li", "ssoia.com", "stanfordujjain.com", "starlight-breaker.net", "starpower.space", "startfu.com", "startkeys.com", "statdvr.com", "stathost.net", "statiix.com", "steambot.net", "stexsy.com", "stinkefinger.net", "stop-my-spam.cf", "stop-my-spam.com", "stop-my-spam.ga", "stop-my-spam.ml", "stop-my-spam.pp.ua", "stop-my-spam.tk", "storiqax.top", "storj99.com", "storj99.top", "streetwisemail.com", "stromox.com", "stuckmail.com", "stuffmail.de", "stumpfwerk.com", "suburbanthug.com", "suckmyd.com", "suioe.com", "super-auswahl.de", "supergreatmail.com", "supermailer.jp", "superplatyna.com", "superrito.com", "superstachel.de", "suremail.info", "svip520.cn", "svk.jp", "svxr.org", "sweetpotato.ml", "sweetxxx.de", "swift10minutemail.com", "sylvannet.com", "symphonyresume.com", "syosetu.gq", "syujob.accountants", "szerz.com", "t.psh.me", "tafmail.com", "tafoi.gr", "taglead.com", "tagmymedia.com", "tagyourself.com", "talkinator.com", "tanukis.org", "tapchicuoihoi.com", "taphear.com", "tarzanmail.cf", "tb-on-line.net", "tech69.com", "techemail.com", "techgroup.me", "teerest.com", "teewars.org", "tefl.ro", "telecomix.pl", "teleworm.com", "teleworm.us", "tellos.xyz", "temp-mail.com", "temp-mail.de", "temp-mail.org", "temp-mail.pp.ua", "temp-mail.ru", "temp-mails.com", "temp.headstrong.de", "tempail.com", "tempalias.com", "tempe-mail.com", "tempemail.biz", "tempemail.co.za", "tempemail.com", "tempemail.net", "tempinbox.co.uk", "tempinbox.com", "tempmail.co", "tempmail.de", "tempmail.eu", "tempmail.it", "tempmail.pp.ua", "tempmail.us", "tempmail.ws", "tempmail2.com", "tempmaildemo.com", "tempmailer.com", "tempmailer.de", "tempomail.fr", "temporarily.de", "temporarioemail.com.br", "temporaryemail.net", "temporaryemail.us", "temporaryforwarding.com", "temporaryinbox.com", "temporarymailaddress.com", "tempr.email", "tempsky.com", "tempthe.net", "tempymail.com", "ternaklele.ga", "testore.co", "testudine.com", "thanksnospam.info", "thankyou2010.com", "thatim.info", "thc.st", "theaviors.com", "thebearshark.com", "thecity.biz", "thecloudindex.com", "thediamants.org", "thedirhq.info", "thelightningmail.net", "thelimestones.com", "thembones.com.au", "themostemail.com", "thereddoors.online", "theroyalweb.club", "thescrappermovie.com", "theteastory.info", "thex.ro", "thietbivanphong.asia", "thisisnotmyrealemail.com", "thismail.net", "thisurl.website", "thnikka.com", "thraml.com", "thrma.com", "throam.com", "thrott.com", "throwam.com", "throwawayemailaddress.com", "throwawaymail.com", "throwawaymail.pp.ua", "throya.com", "thunderbolt.science", "thunkinator.org", "thxmate.com", "tiapz.com", "tic.ec", "tilien.com", "timgiarevn.com", "timkassouf.com", "tinoza.org", "tinyurl24.com", "tipsb.com", "tittbit.in", "tiv.cc", "tizi.com", "tkitc.de", "tlpn.org", "tmail.com", "tmail.ws", "tmailinator.com", "tmails.net", "tmpeml.info", "tmpjr.me", "tmpmail.net", "tmpmail.org", "toddsbighug.com", "toiea.com", "tokem.co", "tokenmail.de", "tonymanso.com", "toomail.biz", "toon.ml", "top101.de", "top1mail.ru", "top1post.ru", "topinrock.cf", "topofertasdehoy.com", "topranklist.de", "toprumours.com", "tormail.org", "toss.pw", "tosunkaya.com", "totalvista.com", "totesmail.com", "totoan.info", "tp-qa-mail.com", "tqoai.com", "tqosi.com", "tradermail.info", "tranceversal.com", "trash-amil.com", "trash-mail.at", "trash-mail.cf", "trash-mail.com", "trash-mail.de", "trash-mail.ga", "trash-mail.gq", "trash-mail.ml", "trash-mail.tk", "trash-me.com", "trash2009.com", "trash2010.com", "trash2011.com", "trashcanmail.com", "trashdevil.com", "trashdevil.de", "trashemail.de", "trashemails.de", "trashinbox.com", "trashmail.at", "trashmail.com", "trashmail.de", "trashmail.gq", "trashmail.io", "trashmail.me", "trashmail.net", "trashmail.org", "trashmail.ws", "trashmailer.com", "trashmails.com", "trashymail.com", "trashymail.net", "trasz.com", "trayna.com", "trbvm.com", "trbvn.com", "trbvo.com", "trgovinanaveliko.info", "trialmail.de", "trickmail.net", "trillianpro.com", "trollproject.com", "tropicalbass.info", "trungtamtoeic.com", "tryalert.com", "tryninja.io", "tryzoe.com", "ttszuo.xyz", "tualias.com", "turoid.com", "turual.com", "tvchd.com", "tverya.com", "twinmail.de", "twkly.ml", "twocowmail.net", "twoweirdtricks.com", "txtadvertise.com", "tyhe.ro", "tyldd.com", "uacro.com", "ubismail.net", "ubm.md", "ucche.us", "ucupdong.ml", "uemail99.com", "ufacturing.com", "uggsrock.com", "uguuchantele.com", "uhhu.ru", "uiu.us", "ujijima1129.gq", "uk.to", "umail.net", "undo.it", "unids.com", "unimark.org", "unit7lahaina.com", "unmail.ru", "upliftnow.com", "uplipht.com", "uploadnolimit.com", "upozowac.info", "urfunktion.se", "uroid.com", "us.af", "us.to", "usa-cc.usa.cc", "used-product.fr", "username.e4ward.com", "ushijima1129.cf", "ushijima1129.ga", "ushijima1129.gq", "ushijima1129.ml", "ushijima1129.tk", "utiket.us", "uu.gl", "uu2.ovh", "uwork4.us", "uyhip.com", "vaasfc4.tk", "vaati.org", "valemail.net", "valhalladev.com", "vankin.de", "vctel.com", "vda.ro", "vdig.com", "veanlo.com", "vemomail.win", "venompen.com", "veo.kr", "ver0.cf", "ver0.ga", "ver0.gq", "ver0.ml", "ver0.tk", "vercelli.cf", "vercelli.ga", "vercelli.gq", "vercelli.ml", "verdejo.com", "veryday.ch", "veryday.eu", "veryday.info", "veryrealemail.com", "vesa.pw", "vfemail.net", "vickaentb.tk", "victime.ninja", "victoriantwins.com", "vidchart.com", "viditag.com", "viewcastmedia.com", "viewcastmedia.net", "viewcastmedia.org", "vikingsonly.com", "vinernet.com", "vipepe.com", "vipmail.name", "vipmail.pw", "vipxm.net", "viralplays.com", "visal007.tk", "visal168.cf", "visal168.ga", "visal168.gq", "visal168.ml", "visal168.tk", "vixletdev.com", "vkcode.ru", "vmailing.info", "vmani.com", "vmpanda.com", "vnedu.me", "voidbay.com", "voltaer.com", "vomoto.com", "vorga.org", "votiputox.org", "voxelcore.com", "vpn.st", "vps30.com", "vps911.net", "vrmtr.com", "vsimcard.com", "vssms.com", "vtxmail.us", "vubby.com", "vuiy.pw", "vztc.com", "w3internet.co.uk", "wakingupesther.com", "walala.org", "walkmail.net", "walkmail.ru", "wallm.com", "wasteland.rfc822.org", "watch-harry-potter.com", "watchever.biz", "watchfull.net", "watchironman3onlinefreefullmovie.com", "wazabi.club", "wbml.net", "web-contact.info", "web-ideal.fr", "web-mail.pp.ua", "web2mailco.com", "webcontact-france.eu", "webemail.me", "webm4il.info", "webmail.igg.biz", "webtrip.ch", "webuser.in", "wee.my", "wef.gr", "wefjo.grn.cc", "weg-werf-email.de", "wegwerf-email-addressen.de", "wegwerf-email-adressen.de", "wegwerf-email.at", "wegwerf-email.de", "wegwerf-email.net", "wegwerf-emails.de", "wegwerfadresse.de", "wegwerfemail.com", "wegwerfemail.de", "wegwerfemail.info", "wegwerfemail.net", "wegwerfemail.org", "wegwerfemailadresse.com", "wegwerfmail.de", "wegwerfmail.info", "wegwerfmail.net", "wegwerfmail.org", "wegwerpmailadres.nl", "wegwrfmail.de", "wegwrfmail.net", "wegwrfmail.org", "welikecookies.com", "wemel.top", "wetrainbayarea.com", "wetrainbayarea.org", "wfgdfhj.tk", "wg0.com", "wh4f.org", "whatiaas.com", "whatifanalytics.com", "whatpaas.com", "whatsaas.com", "whiffles.org", "whopy.com", "whtjddn.33mail.com", "whyspam.me", "wibblesmith.com", "wickmail.net", "widaryanto.info", "widget.gg", "wierie.tk", "wikidocuslava.ru", "wilemail.com", "willhackforfood.biz", "willselfdestruct.com", "wimsg.com", "winemaven.info", "wins.com.br", "wlist.ro", "wmail.cf", "wmail.club", "wokcy.com", "wolfmail.ml", "wolfsmail.tk", "wollan.info", "worldspace.link", "wpg.im", "wralawfirm.com", "writeme.us", "wronghead.com", "wudet.men", "wuespdj.xyz", "wupics.com", "wuzup.net", "wuzupmail.net", "www.e4ward.com", "wwwnew.eu", "wxnw.net", "x24.com", "xagloo.co", "xagloo.com", "xbaby69.top", "xcode.ro", "xcodes.net", "xcompress.com", "xcpy.com", "xemaps.com", "xemne.com", "xents.com", "xing886.uu.gl", "xjoi.com", "xl.cx", "xmail.com", "xmaily.com", "xn--9kq967o.com", "xn--d-bga.net", "xost.us", "xoxox.cc", "xperiae5.com", "xrho.com", "xvx.us", "xwaretech.com", "xwaretech.info", "xwaretech.net", "xww.ro", "xxhamsterxx.ga", "xxi2.com", "xxlocanto.us", "xxolocanto.us", "xxqx3802.com", "xy9ce.tk", "xyzfree.net", "xzsok.com", "yabai-oppai.tk", "yahmail.top", "yahooproduct.net", "yamail.win", "yanet.me", "yannmail.win", "yapped.net", "yaqp.com", "ycare.de", "ycn.ro", "ye.vc", "yedi.org", "yep.it", "yert.ye.vc", "yhg.biz", "ynmrealty.com", "yodx.ro", "yogamaven.com", "yomail.info", "yoo.ro", "yopmail.com", "yopmail.fr", "yopmail.gq", "yopmail.net", "yopmail.pp.ua", "yopmail.usa.cc", "yordanmail.cf", "you-spam.com", "yougotgoated.com", "youmail.ga", "youmailr.com", "youneedmore.info", "youpymail.com", "yourdomain.com", "youremail.cf", "yourewronghereswhy.com", "yourlms.biz", "yourtube.ml", "yroid.com", "yspend.com", "ytpayy.com", "yugasandrika.com", "yui.it", "yuoia.com", "yuurok.com", "yxzx.net", "yyolf.net", "z0d.eu", "z1p.biz", "z86.ru", "zain.site", "zainmax.net", "zaktouni.fr", "zasod.com", "zdenka.net", "zebins.com", "zebins.eu", "zehnminuten.de", "zehnminutenmail.de", "zepp.dk", "zetmail.com", "zfymail.com", "zhaoyuanedu.cn", "zhcne.com", "zhewei88.com", "zhorachu.com", "zik.dj", "zipcad.com", "zippymail.info", "zipsendtest.com", "zoaxe.com", "zoemail.com", "zoemail.net", "zoemail.org", "zoetropes.org", "zombie-hive.com", "zomg.info", "zsero.com", "zumpul.com", "zv68.com", "zxcv.com", "zxcvbnm.com", "zymuying.com", "zzi.us", "zzz.com" };
                var temp = user.EmailId.Split('@')[1];
                foreach (var item in tempMail)
                {
                    if (temp == item)
                    {
                        status = false;
                        Test = -99;
                    }

                }
                if (status == true)
                {
                    Users regObj = new Users();
                    regObj.EmailId = user.EmailId;
                    regObj.UserPassword = user.UserPassword;
                    regObj.Gender = user.Gender;
                    regObj.DateOfBirth = user.DateOfBirth;
                    regObj.Address = user.Address;
                    regObj.Location = user.Location;
                    regObj.SecurityAnswer = user.SecurityAnswer;
                    regObj.SecurityPin = user.SecurityPin;
                    regObj.ContactNo = user.ContactNo;
                    regObj.Zipcode = user.Zipcode;
                    regObj.RoleId = 2;
                    _context.Users.Add(regObj);
                    _context.SaveChanges();
                    status = true;
                    Test = 1;
                }


            }
            catch (Exception ex)
            {
                status = false;
                Test = -99;
            }
            return status;
        }

        public byte? OFD_ValidateCredentials(string userId, string password)
        {
            try
            {
                Users user = _context.Users.Find(userId);
                byte? roleId = 0;
                if (user != null)
                {
                    if (user.UserPassword == password)
                    {
                        roleId = user.RoleId;
                        Test = 1;
                    }
                   
                }
                else {
                    Test = -99;
                }
                return roleId;
            }

            catch (Exception) {
                Test = -99;
                return 0;

            }
            

        }

        #endregion-Demo


        public bool OFD_Checkout(decimal cardDetails, long amount, int cvv, int pin)
        {
            bool status = false;
            try
            {
                var balance = (from p in _context.CardDetails
                               where p.CardNumber.Equals(cardDetails)
                               select p).FirstOrDefault();
                if (balance.Balance >= amount && balance.Cvvnumber == cvv && pin == 123)
                {
                    balance.Balance = balance.Balance - amount;
                    _context.SaveChanges();
                    status = true;
                    Test = 1;
                }
            }
            catch (Exception)
            {
                Test = -99;
                status = false;
            }
            return status;

        }

        public bool OFD_PurchaseProduct(PurchaseDetails purchaseDetails)
        {
            //decimal amount;
            try
            {
                var product = (from p in _context.Products
                               where p.ProductId.Equals(purchaseDetails.Product)
                               select p).FirstOrDefault();
                //amount = product.Price * purchaseDetails.QuantityPurchased;
                product.QuantityAvailable = product.QuantityAvailable - purchaseDetails.QuantityPurchased;
                _context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                //amount = 0;
                return false;
            }

            //return amount;
        }

        public bool OFD_AddCard(CardDetails c)
        {
            bool status = false;
            try
            {
                //CardDetails card = new CardDetails();
                //card.Balance = c.Balance;
                //card.CardNumber = c.CardNumber;
                //card.CardType = c.CardType;
                //card.Cvvnumber = c.Cvvnumber;
                //card.ExpiryDate = c.ExpiryDate;
                //card.NameOnCard = c.NameOnCard;
                _context.CardDetails.Add(c);

                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;

        }



        public bool OFD_AddTransaction(Transaction t)
        {
            bool status = false;
            try
            {
                
                _context.Transaction.Add(t);

                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;

        }

        public bool OFD_CheckAmountDeviation(string acn, decimal amt)
        {
            decimal avg = 0;
            bool status = false;

            List<decimal> transaction = new List<decimal>();
            try
            {
                transaction = (from p in _context.Transaction
                               where p.AccountNumber == acn
                               select p.Amount).ToList();
                if (transaction.Count!=0)
                {
                    avg = transaction.Average();
                    if (amt > (avg + ((decimal)0.95 * avg)) || amt < (avg - ((decimal)0.95 * avg)))
                    {
                        status = true;
                        Test = 1;
                    }
                }
                else
                {
                    Test = -99;
                }
                return status;
            }
            catch (Exception)
            {
                Test = -99;
                transaction = null;
                return status;
            }
        }

        public bool OFD_CheckLocation(string acn, string lcn)
        {

            bool status = true;

            List<string> location = new List<string>();
            try
            {
                location = (from p in _context.Transaction
                            where p.AccountNumber == acn
                            select p.Location).ToList();
                if (location.Count != 0) {
                    foreach (string a in location)
                    {
                        if (a == lcn)
                        {
                            status = false;
                            Test = 1;
                            break;
                            
                        }
                    }
                }
                return status;
            }
            catch (Exception)
            {
                Test = -99;
                return status;
            }
        }

        public bool OFD_TransTime(string acn,int zipcode)
        {

            bool status = true;

            DateTime time2 = new DateTime();
            DateTime time = new DateTime();
            time2 = DateTime.Now;
            List<int> pin = new List<int>();
            
            try
            {
                time = (from p in _context.Transaction
                        where p.AccountNumber == acn
                        select p.TransactionDateTime).Last();
                pin = (from p in _context.Transaction where p.AccountNumber == acn select p.Zipcode).ToList();
            }
            catch (Exception)
            {
                time = DateTime.Now;
            }
            
            if ((time2-time).TotalMinutes < 60)
            {
                foreach(int z in pin)
                {
                    if (z == zipcode)
                    {
                        status = false;
                        break;
                    }
                }

               
            }
            else
            {
                status = false;
            }
            


            return status;

        }

        public bool OFD_CheckIp(string acn,string ip)
        {
            bool status = true;

            List<string> i = new List<string>();
            try
            {
                i = (from p in _context.Transaction
                     where p.AccountNumber == acn
                     select p.IpAddress).ToList();
                if (i.Count != 0)
                {
                    foreach (string x in i)
                    {
                        if (x == ip)
                        {
                            status = false;
                            Test = 1;
                            break;
                        }
                    }

                }
                return status;
            }
            catch (Exception)
            {
                Test = -99;
                return status;
            }
        }
        public bool OFD_ResetPassword(string emailId, string securityAnswer, int securityPin, string newPassword)
        {
            bool status = false;
            try
            {
                var user = (from u in _context.Users
                            where u.EmailId == emailId
                            select u).FirstOrDefault<Users>();
                if (user.SecurityAnswer == securityAnswer && user.SecurityPin == securityPin)
                {

                    user.UserPassword = newPassword;
                    _context.SaveChanges();
                    status = true;

                }
            }
            catch (Exception)
            {

                status = false;
            }


            return status;
        }



        public string OFD_SecurityAnswer(string email)
        {


            try
            {
                var answer = (from c in _context.Users
                              where c.EmailId == email
                              select c.SecurityAnswer).FirstOrDefault();
                return answer;
            }
            catch (Exception)
            {
                return null;
            }


        }




        public bool OFD_ActivationCheck(string acn)
        {
            bool? check = (from c in _context.Account where c.AccountNumber == acn select c.IsActive).FirstOrDefault();
            if ((bool)check)
            {
                Test = 1;
                return true;
            }
            else
            {
                Test = -99;
                return false;
            }
        }


        public int OFD_SecurityPin(string email)
        {


            try
            {
                var pin = (from c in _context.Users
                           where c.EmailId == email
                           select c.SecurityPin).FirstOrDefault();
                Test = 1;
                return pin;
            }
            catch (Exception)
            {
                Test = -99;
                return 0;
            }


        }




    }
}

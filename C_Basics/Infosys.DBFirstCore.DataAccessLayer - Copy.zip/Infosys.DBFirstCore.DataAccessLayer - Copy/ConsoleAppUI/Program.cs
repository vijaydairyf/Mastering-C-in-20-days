﻿using Infosys.DBFirstCore.DataAccessLayer;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using System;
using System.Net;



namespace ConsoleAppUI
{
    class Program
    {
        public static string GetIp()
        {
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            Console.WriteLine(hostName);
            // Get the IP  
            string myIP = Dns.GetHostByName(hostName).AddressList[1].ToString();
            Console.WriteLine("My IP Address is :" + myIP);
            Console.ReadKey();
            return myIP;
        }

        static void Main(string[] args)
        {
            OFD_Repository tell = new OFD_Repository();

            Products aa = new Products();
            aa.ProductName = "aaa";
            aa.QuantityAvailable = 5;
            aa.Price = 1000;
            aa.CategoryId = 8;
            aa.ProductId = "P159";
            Console.WriteLine(tell.OFD_AddProduct(aa));

            //Users user = new Users();
            //user.EmailId = "Ab@xyz.com";
            //user.UserPassword = "abcvdf";
            //user.SecurityPin = 123456;
            //user.SecurityAnswer = "dog";
            //user.Location = "india";
            //user.Gender = "M";
            //user.DateOfBirth = new DateTime(1963 - 12 - 23);
            //user.Address = "Rohtak Haryana";
            //user.ContactNo = 9876543210;

            //var categories = tell.Users(user);
            //CardDetails c = new CardDetails();
            //DateTime date = new DateTime(2020, 11, 11);
            //c.CardNumber = 3146665296881890;
            //c.NameOnCard = "Manuelkk";
            //c.CardType = "M";
            //c.Cvvnumber = 108;
            //c.ExpiryDate = date;
            //c.Balance = 5000;
            //bool status = tell.AddCard(c);

            //PurchaseDetails p = new PurchaseDetails();
            //p.EmailId = "dajkdh@gmail.com";
            //p.Product = "P107";
            //p.QuantityPurchased = 2;


            //Products product = new Products();
            //product.ProductName = "Oil Painting";
            //product.ProductId ="P158";
            //product.Price = 500;
            //product.QuantityAvailable = 20;
            //product.CategoryId = 4;
            //var categories=tell.GetCustomerDetails(1000000004);
            //Console.WriteLine("----------------------------------");
            //Console.WriteLine("CategoryId\tCategoryName");
            //Console.WriteLine("----------------------------------");
            //foreach (var category in categories)
            //{
            var e = tell.OFD_DeleteCategory(7);
            Console.WriteLine(e);
            //}


            //string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            //Console.WriteLine(hostName);
            //// Get the IP  
            //string myIP = Dns.GetHostByName(hostName).AddressList[1].ToString();
            //Console.WriteLine("My IP Address is :" + myIP);
            //Console.ReadKey();





        }

       
    }
}

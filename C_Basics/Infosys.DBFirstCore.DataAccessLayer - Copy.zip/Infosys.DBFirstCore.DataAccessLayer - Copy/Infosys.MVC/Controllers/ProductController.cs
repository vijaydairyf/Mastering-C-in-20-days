﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.DBFirstCore.DataAccessLayer;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using Infosys.MVC.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.MVC.Controllers
{
    public class ProductController : Controller
    {
        
        DataContext db = new DataContext();


        private readonly IMapper _mapper;
        OFD_Repository tel;
        public ProductController(IMapper mapper, OFD_Repository telerr)
        {
           
            _mapper = mapper;
            tel = telerr;
        }

        public IActionResult Login()
        {
            return View();
        }



        public IActionResult ViewProduct()
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }

            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProducts();
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }


        public IActionResult AddProduct()
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var productId = tel.OFD_GetNextProductId();
            ViewBag.ProductId = productId;
            return View();
        }


        [HttpPost]
        public IActionResult SaveAddedProduct(Models.Products prod)
        {

            var retValue = tel.OFD_AddProduct(_mapper.Map<DBFirstCore.DataAccessLayer.Models.Products>(prod));
            if (retValue)
            {
                return RedirectToAction("ViewProduct");
            }
            else
            {
                return View("Error5");
            }
        }






        public IActionResult ViewCategory()
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetCategories();
            List < Models.Categories> lstmodelproducts = new List<Models.Categories>();
            foreach (var cat in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Categories>(cat));
            }
            return View(lstmodelproducts);
        }


        public IActionResult AddCategory()
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");

            return View();
        }


        [HttpPost]
        public IActionResult SaveAddedCategory(Models.Categories prod)
        {
            
            var retValue = tel.OFD_AddCategory(prod.CategoryName);
            if (retValue)
            {
                return RedirectToAction("ViewCategory");
            }
            else
            {
                return View("Error5");
            }
        }







        public IActionResult ViewArtProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(4);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }


        public IActionResult ViewElectronicsProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(3);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }



        public IActionResult ViewFashionProduct()
        {
            
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(2);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }



        public IActionResult ViewHomeDecProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(5);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }


        public IActionResult ViewMotorProduct()
        {
            
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(1);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }



        public IActionResult ViewSportProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(6);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }



        public IActionResult ViewToyProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(7);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }



        public IActionResult ViewGroceriesProduct()
        {
           
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(9);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }


        public IActionResult ViewBookProduct()
        {
            
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetProductsByCategory(8);
            List<Models.Products> lstmodelproducts = new List<Models.Products>();
            foreach (var product in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Products>(product));
            }
            return View(lstmodelproducts);
        }

        // GET: Product
        public ActionResult Index()
        {
            ViewBag.products = db.Products.ToList();
            return View();
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(Models.Products p)
        {
            return View();
        }

        public ActionResult SaveEdit(IFormCollection frm)
        {
            Models.Products prod = new Models.Products();
            prod.ProductId = frm["ProductId"];
            prod.ProductName = frm["ProductName"];
            prod.QuantityAvailable = Convert.ToInt32(frm["QuantityAvailable"]);
            prod.Price = Convert.ToDecimal(frm["Price"]);
            prod.CategoryId =Convert.ToByte( frm["CategoryId"]);
            tel.OFD_UpdateProduct(_mapper.Map<DBFirstCore.DataAccessLayer.Models.Products>(prod));

            return RedirectToAction("ViewProduct");
        }

        // POST: Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        public ActionResult DeleteProduct(Models.Products p)
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            return View(p);

        }

        [HttpPost]
        public ActionResult SaveDelete(string productId)
        {
            tel.OFD_DeleteProduct(productId);
            return RedirectToAction("ViewProduct");

        }


        // POST: Product/Delete/5
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Delete(int id, IFormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        public ActionResult Detail(Models.Products p)
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            Models.Products prod = _mapper.Map<Models.Products>(p);
            return View(prod);
        }







        public ActionResult DeleteCategory(Models.Categories c)
        {
            return View(c);

        }

        [HttpPost]
        public ActionResult SaveDeleteCategory(byte categID)
        {
           
            tel.OFD_DeleteCategory(categID);
            return RedirectToAction("ViewCategory");

        }




    }
}
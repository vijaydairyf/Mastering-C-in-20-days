﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.DBFirstCore.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.MVC.Controllers
{
    public class TransactionController : Controller
    {


        private readonly IMapper _mapper;
        OFD_Repository tel;
        public TransactionController(IMapper mapper, OFD_Repository telerr)
        {
            _mapper = mapper;
            tel = telerr;
        }


        public IActionResult ViewTransaction()
        {
            if (HttpContext.Session.GetString("Role") != "1")
            {
                return RedirectToAction("Login", "Home");
            }
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetTransactionDetails();
            List < Models.Transaction> lstmodelproducts = new List<Models.Transaction>();
            foreach (var trans in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Transaction>(trans));
            }
            return View(lstmodelproducts);
        }




        public IActionResult ViewUserTransaction()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            TempData["email"] = HttpContext.Session.GetString("email");
            TempData["count"] = HttpContext.Session.GetString("count");
            var lstEntityProducts = tel.OFD_GetSpecificTransactionDetails(TempData["email"].ToString());
            List<Models.Transaction> lstmodelproducts = new List<Models.Transaction>();
            foreach (var trans in lstEntityProducts)
            {
                lstmodelproducts.Add(_mapper.Map<Models.Transaction>(trans));
            }
            return View(lstmodelproducts);
        }








        // GET: Transaction
        public ActionResult Index()
        {
            return View();
        }

        // GET: Transaction/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Transaction/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Transaction/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Transaction/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Transaction/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Transaction/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Transaction/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
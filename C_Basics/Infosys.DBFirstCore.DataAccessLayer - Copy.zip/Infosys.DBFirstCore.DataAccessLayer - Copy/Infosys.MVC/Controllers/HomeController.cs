﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Infosys.MVC.Models;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using Infosys.DBFirstCore.DataAccessLayer.Models;
using Infosys.DBFirstCore.DataAccessLayer;
//using Microsoft.AspNetCore.Http;

namespace Infosys.MVC.Controllers
{
    public class HomeController : Controller
    {
        

        static string luser;
        static string name;
        static int count=0;
        private readonly IMapper _mapper;
        OFD_Repository tel;
        public HomeController(IMapper mapper,OFD_Repository telerr)
        {
            _mapper =mapper;
             tel = telerr;
        }
        public IActionResult Guest()
        {
            return View();
        }
        
        public IActionResult Customer()
        {
            TempData["email"] = HttpContext.Session.GetString("email");
            if (HttpContext.Session.GetString("email") == null || HttpContext.Session.GetString("Role") != "2")
            {
                return RedirectToAction("Login", "Home");
            }
            return View();
        }


        public IActionResult Home2()
        {
            TempData["count"] = HttpContext.Session.GetString("count");
            string role = HttpContext.Session.GetString("Role");
            if (role == "2")
            {
                return Redirect("/Home/Customer?user=" + luser);
            }
            else if (role == "1")
            {
                return Redirect("/Home/Admin?user=" + luser);
            }
            else
            {
                TempData["Message"] = "wrongPassword";
                return RedirectToAction("Login");
            }
        }

        public IActionResult Home3()
        {
            return Redirect("/Home/Admin?user=" + luser);
        }


        public IActionResult CartDirect()
        {
            return RedirectToAction("Index", "AddToCart");
           
        }


     
        public IActionResult Registerr()
        {
            return View();
        }
        public IActionResult Admin()
        {
            TempData["email"] = HttpContext.Session.GetString("email");
            if (HttpContext.Session.GetString("email") == null || HttpContext.Session.GetString("Role")!="1")
            {
                return RedirectToAction("Login", "Home");
            }
            return View();
        }


        public IActionResult ResetPassword(IFormCollection frm)
        {
            bool status = false;
            try
            {

                var EmailId = frm["email"];
                var SecurityAnswer = frm["sec"];
                var SecurityPin = Convert.ToInt32(frm["pin"]);
                var UserPassword = frm["password"];
                status = tel.OFD_ResetPassword(EmailId, SecurityAnswer, SecurityPin, UserPassword);

                
            }
            catch (Exception)
            {

                //TempData["Message"] = "Incorrect Details";
                return View("Guest");
            }
            if (status == true)
            {
                TempData["Message"]= "Success";
                return RedirectToAction("Login");
            }
            else
            {
                //TempData["Message"] = "errorororrr";
                return View("ResetPassword");
            }

        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Login()
        {
            name = null;
            string role = HttpContext.Session.GetString("Role");
            if (role == "2")
            {
                return Redirect("/Home/Customer?user=" + luser);
            }
            else if (role == "1")
            {
                return Redirect("/Home/Admin?user=" + luser);
            }
            else
            {
                return View();
            }
            
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("email");
            HttpContext.Session.Remove("Role");
            HttpContext.Session.Clear();

            return RedirectToAction("Guest", "Home");
        }


        public IActionResult CheckRole(IFormCollection frm)
        {
            
            string userId = frm["user"];
            string password = frm["pass"];
            string checkbox = frm["RememberMe"];
            string role = HttpContext.Session.GetString("Role");
            if (role == "2")
            {
                return Redirect("/Home/Customer?user=" + luser);
            }
            else if (role == "1")
            {
                return Redirect("/Home/Admin?user=" + luser);
            }
            else
            {


                if (checkbox == "on")
                {
                    CookieOptions option = new CookieOptions();
                    option.Expires = DateTime.Now.AddDays(1);
                    Response.Cookies.Append("UserId", userId, option);
                    Response.Cookies.Append("Password", password, option);
                }
                string username = userId.Split('@')[0];
                luser = username;
                byte? roleId = tel.OFD_ValidateCredentials(userId, password);
                if (roleId == 1)
                {
                    count = 0;
                    HttpContext.Session.SetString("email", userId);
                    TempData["email"] = userId;
                    HttpContext.Session.SetString("Role", "1");


                    // RedirectToAction("Index3", "Home");
                    return RedirectToAction("Home2");
                }
                else if (roleId == 2)
                {
                    count = 0;
                    HttpContext.Session.SetString("email", userId);
                    TempData["email"] = userId;
                    HttpContext.Session.SetString("Role", "2");

                    // return RedirectToAction("Index2", "Home");
                    return RedirectToAction("Home2");
                }

                else if (roleId == 0)
                {
                    count++;
                    if (count == 1 || count == 2 || count == 3||count==0)
                    {
                        //Console.WriteLine("NA");
                        TempData["Message"] = "Invalid";
                        return RedirectToAction("Home2");

                    }

                    else
                    {
                        
                        return View("Error2");
                    }
                }
                return View("Login");
            }



               
        }




        public IActionResult Register(IFormCollection frm)
        {

            bool status = false;
            try
            {
                Models.Users user = new Models.Users();
                string date = frm["dob"];
                DateTime d = Convert.ToDateTime(date);
            
                user.Address = frm["add"];
                user.ContactNo = Convert.ToInt64(frm["num"]);
                user.DateOfBirth = d;
                user.Gender = frm["gender"];
                user.EmailId = frm["email"];
                user.UserPassword = frm["password"];
                user.Location = frm["loc"];
                user.SecurityAnswer = frm["sec"];
                user.SecurityPin = Convert.ToInt32(frm["pin"]);
                user.Zipcode = Convert.ToInt32(frm["zip"]);
                status = tel.OFD_Users(_mapper.Map<DBFirstCore.DataAccessLayer.Models.Users>(user));
            }
            catch
            {
                return View("Login");
            }
            if (status == true)
            {
                TempData["Message"] = "successregister";
                return RedirectToAction("Login", "Home");
            }
            else
            {
                TempData["Message"] = "Incorrect setail entered";
                return View("Login");
            }

            
            //byte? roleId = tel.ValidateCredentials(userId, password);
            //if (roleId == 1)
            //{
            //    return RedirectToAction("Index", "Home");
            //}
            //else if (roleId == 2)
            //{
            //    return RedirectToAction("Index", "Home");
            //}
            //return View("Login");
        }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
